# Amour - Bot WhatsApp 

Généré par **BotForge**

## Installation

1. **Node.js 18+** requis
2. `npm install`
3. Modifiez le fichier `.env`
4. `npm start`

## Configuration (.env)

- `BOT_NUMBER` : Numéro WhatsApp (sans +)
- `PREFIXE` : Préfixe des commandes (défaut: !)
- `BOT_NAME` : Amour


## Commandes

Tapez `!menu` pour voir toutes les commandes.


---
Généré par BotForge • 29/03/2026
