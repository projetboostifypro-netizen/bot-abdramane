import {
  useMultiFileAuthState, makeWASocket, DisconnectReason,
  fetchLatestBaileysVersion, makeCacheableSignalKeyStore,
} from "@whiskeysockets/baileys";
import qrcodeTerminal from "qrcode-terminal";
import pino from "pino";
import NodeCache from "node-cache";
import fs from "fs";
import dotenv from "dotenv";
import fetch from "node-fetch";
dotenv.config();

export const config = {
  PREFIXE: process.env.PREFIXE || "!",
  AUTH_DIR: process.env.AUTH_DIR || "auth_baileys",
  NUMBER: process.env.BOT_NUMBER,
  USE_QR: process.env.USE_QR === "true",
  LOG_LEVEL: process.env.LOG_LEVEL || "info",
  RECONNECT_DELAY: parseInt(process.env.RECONNECT_DELAY) || 5000,
  BOT_NAME: process.env.BOT_NAME || "Amour",
  COMPANY_NAME: process.env.COMPANY_NAME || "Boostifypro",
  OPENAI_API_KEY: process.env.OPENAI_API_KEY || "",
  OPENAI_BASE_URL: (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, ""),
  OPENAI_MODEL: process.env.OPENAI_MODEL || "gpt-4o-mini",
};

const logger = pino({
  level: config.LOG_LEVEL,
  transport: { target: "pino-pretty", options: { colorize: true, ignore: "pid,hostname", translateTime: "HH:MM:ss", includeStack: true } },
  base: null,
  serializers: { error: pino.stdSerializers.error },
});
const msgRetryCounterCache = new NodeCache();
const processedMessages = new Set();
const conversationHistory = new Map();
let socket, intervalId, heartbeatInterval;

function startHeartbeat(sock) {
  if (heartbeatInterval) clearInterval(heartbeatInterval);
  heartbeatInterval = setInterval(async () => {
    try { await sock.sendPresenceUpdate("available"); } catch {}
  }, 3 * 60 * 1000);
  logger.info("💓 Heartbeat démarré");
}

function cleanAuthFolder() {
  try { fs.rmSync(config.AUTH_DIR, { recursive: true, force: true }); logger.info("Dossier d'authentification nettoyé"); } catch {}
}

async function requestPairingCode(sock) {
  try {
    logger.info(`Demande de code de pairing pour ${config.NUMBER}`);
    const code = await sock.requestPairingCode(config.NUMBER);
    const formatted = code.length === 8 ? `${code.slice(0, 4)}-${code.slice(4)}` : code;
    console.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`🔑  CODE DE COUPLAGE WHATSAPP : ${formatted}`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`📱 WhatsApp → Appareils connectés → Lier avec numéro → Entrez: ${formatted}`);
    console.log(`⏱  Valable 60 secondes.\n`);
    let countdown = 60;
    intervalId = setInterval(() => { countdown -= 10; if (countdown > 0) logger.info(`🔑 Code: ${formatted} (expire dans ${countdown}s)`); }, 10000);
    setTimeout(() => { clearInterval(intervalId); logger.warn("⏰ Code expiré. Redémarrez le bot."); }, 60000);
  } catch (err) {
    logger.error({ error: err }, "Échec du code de pairing");
    throw err;
  }
}

// Extract text from any message type (handles ephemeral, viewOnce, etc.)
function extractMessageText(msg) {
  const m = msg.message;
  if (!m) return "";
  // Direct conversation
  if (m.conversation) return m.conversation;
  if (m.extendedTextMessage?.text) return m.extendedTextMessage.text;
  // Ephemeral messages
  if (m.ephemeralMessage?.message) {
    const em = m.ephemeralMessage.message;
    if (em.conversation) return em.conversation;
    if (em.extendedTextMessage?.text) return em.extendedTextMessage.text;
  }
  // View once messages
  if (m.viewOnceMessage?.message) {
    const vm = m.viewOnceMessage.message;
    if (vm.conversation) return vm.conversation;
    if (vm.extendedTextMessage?.text) return vm.extendedTextMessage.text;
  }
  if (m.viewOnceMessageV2?.message) {
    const vm = m.viewOnceMessageV2.message;
    if (vm.conversation) return vm.conversation;
    if (vm.extendedTextMessage?.text) return vm.extendedTextMessage.text;
  }
  // Image/video/document with caption
  if (m.imageMessage?.caption) return m.imageMessage.caption;
  if (m.videoMessage?.caption) return m.videoMessage.caption;
  if (m.documentMessage?.caption) return m.documentMessage.caption;
  return "";
}

// ━━━━━━━━━━━━━━━ AI AUTO-REPLY ━━━━━━━━━━━━━━━
async function callAI(messages) {
  if (!config.OPENAI_API_KEY) return null;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);
    const response = await fetch(`${config.OPENAI_BASE_URL}/chat/completions`, {
      method: "POST",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${config.OPENAI_API_KEY}` },
      body: JSON.stringify({ model: config.OPENAI_MODEL, messages, max_tokens: 500, temperature: 0.7 }),
    });
    clearTimeout(timeout);
    if (response.ok) {
      const data = await response.json();
      return data.choices?.[0]?.message?.content || null;
    }
    return null;
  } catch { return null; }
}

async function handleAIReply(sock, msg, from, text) {
  if (!config.OPENAI_API_KEY) return;
  const senderId = msg.key.participant || msg.key.remoteJid;
  const clientName = msg.pushName || "ami";
  if (!conversationHistory.has(senderId)) conversationHistory.set(senderId, []);
  const history = conversationHistory.get(senderId);
  const systemPrompt = `Tu es ${config.BOT_NAME}, un assistant WhatsApp intelligent créé par ${config.COMPANY_NAME}. Tu réponds en français de manière naturelle et utile. Utilise le formatage WhatsApp (*gras*, _italique_). Le client s'appelle ${clientName}.`;
  const msgs = [{ role: "system", content: systemPrompt }, ...history.slice(-10), { role: "user", content: text }];
  const reply = await callAI(msgs);
  if (reply) {
    history.push({ role: "user", content: text });
    history.push({ role: "assistant", content: reply });
    if (history.length > 20) history.splice(0, 2);
    await sock.sendMessage(from, { text: reply });
    logger.info(`🤖 IA → ${clientName}`);
  }
}

async function startBot() {
  try {
    logger.info(`🚀 Démarrage de ${config.BOT_NAME} Bot by ${config.COMPANY_NAME}...`);
    const { version } = await fetchLatestBaileysVersion();
    const { state, saveCreds } = await useMultiFileAuthState(config.AUTH_DIR);

    socket = makeWASocket({
      version,
      logger: pino({ level: "silent" }),
      printQRInTerminal: false,
      auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, logger) },
      syncFullHistory: false,
      msgRetryCounterCache,
      generateHighQualityLinkPreview: true,
    });

    socket.ev.on("creds.update", saveCreds);

    socket.ev.on("connection.update", ({ connection, lastDisconnect, qr }) => {
      if (qr && config.USE_QR) { qrcodeTerminal.generate(qr, { small: true }); }
      if (!config.USE_QR && qr && config.NUMBER && !state.creds.registered) {
        requestPairingCode(socket).catch(err => logger.error({ err }, "Erreur pairing"));
      }
      if (connection === "open") {
        logger.info(`✅ ${config.BOT_NAME} connecté à WhatsApp !`);
        startHeartbeat(socket);
      }
      if (connection === "close") {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        if (statusCode !== DisconnectReason.loggedOut) {
          clearInterval(intervalId);
          if (heartbeatInterval) clearInterval(heartbeatInterval);
          logger.info("🔄 Reconnexion...");
          setTimeout(startBot, config.RECONNECT_DELAY);
        } else {
          logger.error("Session invalidée.");
          cleanAuthFolder();
        }
      }
    });

    socket.ev.on("messages.upsert", async ({ messages, type }) => {
      if (type !== "notify") return;
      for (const msg of messages) {
        if (!msg.message || msg.key.fromMe) continue;
        // Deduplicate messages
        if (processedMessages.has(msg.key.id)) continue;
        processedMessages.add(msg.key.id);
        if (processedMessages.size > 1000) {
          const arr = [...processedMessages];
          arr.splice(0, 500).forEach(id => processedMessages.delete(id));
        }

        const text = extractMessageText(msg);
        if (!text) continue;
        const from = msg.key.remoteJid;
        const p = config.PREFIXE;

        logger.info({ from, text: text.slice(0, 60), sender: msg.key.participant || from }, "Message reçu");

        if (text.startsWith(p)) {
          const cmd = text.slice(p.length).trim().split(" ")[0].toLowerCase();
          switch (cmd) {
            case "menu": case "help": await socket.sendMessage(from, { text: menu(p) }); break;
            case "ping": await socket.sendMessage(from, { text: "🏓 Pong ! Bot actif." }); break;
            case "info": await socket.sendMessage(from, { text: `🤖 *${config.BOT_NAME}*\n🏢 ${config.COMPANY_NAME}\n⚡ v1.0.0\n📌 Préfixe: ${p}` }); break;
            case "ia": {
              const query = text.slice(p.length + cmd.length).trim();
              if (query) await handleAIReply(socket, msg, from, query);
              else await socket.sendMessage(from, { text: `Usage: ${p}ia [votre question]` });
              break;
            }
            default: await socket.sendMessage(from, { text: `❓ Commande inconnue. Tapez ${p}menu` });
          }
        } else {
          // Auto-reply with AI for non-command messages
          await handleAIReply(socket, msg, from, text);
        }
      }
    });
  } catch (err) {
    logger.error({ err }, "Erreur fatale");
    setTimeout(startBot, config.RECONNECT_DELAY);
  }
}

function menu(p) {
  return `━━━━━━━━━━━━━━━━━━━━
  🤖 *${config.BOT_NAME}*
━━━━━━━━━━━━━━━━━━━━
⚡ ${p}ping - Tester le bot
📋 ${p}menu - Ce menu
🔍 ${p}info - Infos du bot
🤖 ${p}ia [question] - Poser une question à l'IA
━━━━━━━━━━━━━━━━━━━━
💡 Envoyez n'importe quel message pour parler à l'IA !
━━━━━━━━━━━━━━━━━━━━
Généré par BotForge ⚡`;
}
startBot().catch(console.error);
