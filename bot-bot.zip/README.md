# Bot - Bot WhatsApp Premium ⚡

Généré par **BotForge**

## Installation

1. **Node.js 18+** requis
2. `npm install`
3. Modifiez le fichier `.env`
4. `npm start`

## Configuration (.env)

- `BOT_NUMBER` : Numéro WhatsApp (sans +)
- `PREFIXE` : Préfixe des commandes (défaut: !)
- `BOT_NAME` : Bot
- `LICENSE_KEY` : Votre clé de licence premium
- `OPENAI_API_KEY` : Clé API OpenAI (pour l'IA)

## Commandes

Tapez `!menu` pour voir toutes les commandes.

## Fonctionnalités Premium

- 🛡️ Anti-spam, anti-link, anti-insulte, anti-flood, anti-bot
- 👥 Gestion de groupe complète (add, kick, ban, promote, lock...)
- 🎉 Messages de bienvenue et de départ personnalisés
- 🤖 Auto-réponse par mots-clés
- 📢 Broadcast en masse
- ⏰ Messages programmés
- 🎨 Conversion sticker
- 🎮 Jeux et quiz
- 📊 Système de niveaux
- 📦 Modules activables/désactivables
- 📝 Logs complets
- 🔑 Système de licence
- ⚙️ Personnalisation (nom, préfixe)

---
Généré par BotForge • 30/03/2026
