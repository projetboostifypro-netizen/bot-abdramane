const express = require('express');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const crypto = require('crypto');

let jwt, bcrypt, initSqlJs, AdmZip;
try { jwt = require('jsonwebtoken'); } catch { jwt = null; }
try { bcrypt = require('bcryptjs'); } catch { bcrypt = null; }
try { initSqlJs = require('sql.js'); } catch { initSqlJs = null; }
try { AdmZip = require('adm-zip'); } catch { AdmZip = null; }

// ─── Hostinger API ────────────────────────────────────────────────────────────
const HOSTINGER_BASE = 'https://api.hostinger.com/v1';

async function hostingerRequest(method, path, body) {
  const key = process.env.HOSTINGER_API_KEY;
  if (!key) return { error: 'HOSTINGER_API_KEY non configuré' };
  try {
    const opts = {
      method,
      headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(`${HOSTINGER_BASE}${path}`, opts);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { error: data?.message || data?.error || `Hostinger erreur ${res.status}`, status: res.status };
    return { data };
  } catch (e) {
    return { error: e.message };
  }
}

async function hostingerAddRecord(domain, type, name, content, ttl) {
  return hostingerRequest('POST', `/dns/zones/${domain}/records`, { type, name, content, ttl: ttl || 300 });
}

async function hostingerDeleteRecord(domain, recordId) {
  return hostingerRequest('DELETE', `/dns/zones/${domain}/records/${recordId}`);
}

const PORT = Number(process.env.SERVER_PORT || process.env.PORT || 3001);
const HOST = process.env.HOST || '0.0.0.0';
const VPS_IP = process.env.VPS_IP || '51.83.103.24';
const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'bothoster.db');
const SECRET_FILE = path.join(DATA_DIR, '.jwt_secret');
const BOTS_DIR = process.env.BOTS_DIR || path.join(DATA_DIR, 'bots');
const SOLEASPAY_API_KEY = process.env.SOLEASPAY_API_KEY || 'f9N8wY8TD_8C7PvFsacmtmsH_MzozoU_Fkf-XhzkrG4-AP';
const SOLEASPAY_BASE = 'https://soleaspay.com';

let JWT_SECRET;
if (process.env.JWT_SECRET) {
  JWT_SECRET = process.env.JWT_SECRET;
} else if (fs.existsSync(SECRET_FILE)) {
  JWT_SECRET = fs.readFileSync(SECRET_FILE, 'utf8').trim();
} else {
  JWT_SECRET = crypto.randomBytes(48).toString('hex');
  try { fs.writeFileSync(SECRET_FILE, JWT_SECRET); } catch {}
}

fs.mkdirSync(BOTS_DIR, { recursive: true });

// ─── sql.js compatibility wrapper (same API as better-sqlite3) ────────────────
class SqliteDB {
  constructor(sqlInstance, dbPath) {
    this._path = dbPath;
    this._db = fs.existsSync(dbPath)
      ? new sqlInstance.Database(fs.readFileSync(dbPath))
      : new sqlInstance.Database();
  }

  _save() {
    try { fs.writeFileSync(this._path, Buffer.from(this._db.export())); } catch (e) { console.warn('[db] save:', e.message); }
  }

  _flat(args) {
    if (!args.length) return [];
    if (args.length === 1 && Array.isArray(args[0])) return args[0];
    return args.map(v => (v === undefined ? null : v));
  }

  pragma(str) { try { this._db.run(`PRAGMA ${str}`); } catch {} }

  exec(sql) { this._db.exec(sql); this._save(); }

  prepare(sql) {
    const self = this;
    return {
      run(...args) {
        const p = self._flat(args);
        try { self._db.run(sql, p.length ? p : undefined); } catch (e) { console.warn('[db] run:', e.message, sql.slice(0, 60)); throw e; }
        self._save();
        return { changes: self._db.getRowsModified() };
      },
      get(...args) {
        const p = self._flat(args);
        try {
          const stmt = self._db.prepare(sql);
          if (p.length) stmt.bind(p);
          const row = stmt.step() ? stmt.getAsObject() : undefined;
          stmt.free();
          return row;
        } catch (e) { console.warn('[db] get:', e.message, sql.slice(0, 60)); return undefined; }
      },
      all(...args) {
        const p = self._flat(args);
        try {
          const stmt = self._db.prepare(sql);
          if (p.length) stmt.bind(p);
          const rows = [];
          while (stmt.step()) rows.push(stmt.getAsObject());
          stmt.free();
          return rows;
        } catch (e) { console.warn('[db] all:', e.message, sql.slice(0, 60)); return []; }
      }
    };
  }
}

// ─── Global db (set async on startup) ────────────────────────────────────────
let db = null;

// ─── Helpers ──────────────────────────────────────────────────────────────────
const genId = () => crypto.randomUUID();

function signToken(userId) {
  if (!jwt) return 'no-jwt';
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: '30d' });
}
function verifyToken(token) {
  if (!jwt) return null;
  try { return jwt.verify(token, JWT_SECRET); } catch { return null; }
}
function hashPassword(p) {
  if (!bcrypt) return p;
  return bcrypt.hashSync(p, 10);
}
function checkPassword(plain, hash) {
  if (!bcrypt) return plain === hash;
  return bcrypt.compareSync(plain, hash);
}
function normalizeBot(row) {
  if (!row) return null;
  try { row.env_vars = typeof row.env_vars === 'string' ? JSON.parse(row.env_vars) : (row.env_vars || {}); } catch { row.env_vars = {}; }
  return row;
}

// ─── Bot management ───────────────────────────────────────────────────────────
const activeBots = new Map();
const ENTRY_CANDIDATES = {
  nodejs: ['index.js', 'main.js', 'app.js', 'bot.js', 'server.js', 'start.js', 'run.js', 'discord.js', 'telegram.js', 'whatsapp.js', 'src/index.js', 'src/main.js', 'src/bot.js', 'src/app.js'],
  python: ['main.py', 'bot.py', 'index.py', 'app.py', 'run.py', 'start.py', 'src/main.py', 'src/bot.py'],
};
const TEXT_EXTS = new Set(['.js','.mjs','.cjs','.ts','.py','.json','.env','.txt','.yml','.yaml','.md','.sh','.toml','.cfg','.ini','.xml','.html','.css','.jsx','.tsx']);
const EXCLUDE_DIRS = new Set(['node_modules','.git','__pycache__','.venv','venv','dist','build']);

function stripAnsi(str) { return str.replace(/\x1B\[[0-9;]*[mGKHFJA-Z]/g, ''); }
function normalizeBotId(id) { return String(id||'').trim().replace(/[^a-zA-Z0-9_-]/g,''); }
function getBotDirectory(botId) { const s=normalizeBotId(botId); return s ? path.join(BOTS_DIR,s) : null; }
function getUptimeSeconds(startedAt) { return Math.max(0,Math.floor((Date.now()-startedAt)/1000)); }

function parseEnvFile(content) {
  const vars={};
  for(const line of content.split('\n')){const t=line.trim();if(!t||t.startsWith('#'))continue;const eq=t.indexOf('=');if(eq===-1)continue;let v=t.substring(eq+1).trim();if((v.startsWith('"')&&v.endsWith('"'))||(v.startsWith("'")&&v.endsWith("'")))v=v.slice(1,-1);vars[t.substring(0,eq).trim()]=v;}
  return vars;
}

function pushLog(botId, userId, level, message) {
  if (!db || !message) return;
  try { db.prepare('INSERT INTO bot_logs(id,bot_id,user_id,level,message) VALUES(?,?,?,?,?)').run(genId(),botId,userId||null,level,String(message).slice(0,2000)); } catch {}
}

function updateBotStatus(botId, status, extra = {}) {
  if (!db || !botId) return;
  try {
    const fields = { status, updated_at: new Date().toISOString(), ...extra };
    const sets = Object.keys(fields).map(k => `${k}=?`).join(',');
    db.prepare(`UPDATE bots SET ${sets} WHERE id=?`).run(...Object.values(fields), botId);
  } catch (e) { console.warn('[db] updateBotStatus:', e.message); }
}

function resolveRuntime(language) { return language==='python' ? {command:'python3',key:'python'} : {command:'node',key:'nodejs'}; }

function resolveEntryFile(botDir, config={}) {
  const runtime=resolveRuntime(config.language);
  const customs=[config.entry,config.entrypoint,config.start_file].filter(Boolean).map(e=>path.basename(String(e)));
  const candidates=[...customs,...ENTRY_CANDIDATES[runtime.key]];
  const searchDirs=[botDir];
  try{fs.readdirSync(botDir).filter(e=>fs.statSync(path.join(botDir,e)).isDirectory()).forEach(d=>searchDirs.push(path.join(botDir,d)));}catch{}
  for(const dir of searchDirs){for(const c of candidates){const fp=path.join(dir,c);if(fs.existsSync(fp)&&fs.statSync(fp).isFile())return fp;}}
  return null;
}

function buildProcessEnv(envVars, workDir=null) {
  const env={...process.env};
  if(workDir){const dp=path.join(workDir,'.env');if(fs.existsSync(dp)){try{Object.assign(env,parseEnvFile(fs.readFileSync(dp,'utf8')));}catch{}}}
  if(!envVars||typeof envVars!=='object'||Array.isArray(envVars))return env;
  for(const[k,v]of Object.entries(envVars)){if(k)env[String(k)]=v==null?'':String(v);}
  return env;
}

function scanTextFiles(dir,prefix=''){
  const results=[];
  try{for(const entry of fs.readdirSync(dir)){if(EXCLUDE_DIRS.has(entry))continue;const full=path.join(dir,entry);const rel=prefix?`${prefix}/${entry}`:entry;try{const st=fs.statSync(full);if(st.isDirectory())results.push(...scanTextFiles(full,rel));else if(st.size<500*1024){const ext=path.extname(entry).toLowerCase();const base=entry.toLowerCase();const isText=TEXT_EXTS.has(ext)||base==='.env'||base.startsWith('.env.')||base==='.gitignore'||base==='dockerfile'||base==='makefile';if(isText)results.push({rel,full});}}catch{}}}catch{}
  return results;
}

function scanAndStoreBotFiles(botId, botDir) {
  if (!db) return;
  try {
    const files = scanTextFiles(botDir);
    for (const { rel, full } of files) {
      try {
        const content = fs.readFileSync(full, 'utf8');
        const existing = db.prepare('SELECT is_modified FROM bot_files WHERE bot_id=? AND path=?').get(botId, rel);
        if (!existing) {
          db.prepare('INSERT OR IGNORE INTO bot_files(id,bot_id,user_id,path,content) VALUES(?,?,?,?,?)').run(genId(), botId, '', rel, content);
        } else if (!existing.is_modified) {
          db.prepare("UPDATE bot_files SET content=?,updated_at=datetime('now') WHERE bot_id=? AND path=?").run(content, botId, rel);
        }
      } catch {}
    }
  } catch (e) { console.warn('[files] scan error:', e.message); }
}

function applyModifiedFiles(botId, botDir) {
  if (!db) return;
  try {
    const modified = db.prepare('SELECT * FROM bot_files WHERE bot_id=? AND is_modified=1').all(botId);
    for (const file of modified) {
      try {
        const fp = path.join(botDir, file.path);
        fs.mkdirSync(path.dirname(fp), { recursive: true });
        fs.writeFileSync(fp, file.content, 'utf8');
      } catch {}
    }
    if (modified.length) db.prepare('UPDATE bot_files SET is_modified=0 WHERE bot_id=? AND is_modified=1').run(botId);
  } catch (e) { console.warn('[files] apply error:', e.message); }
}

function extractArchive(archivePath, destDir) {
  fs.mkdirSync(destDir, { recursive: true });
  const ext = archivePath.toLowerCase();
  if (ext.endsWith('.zip')) {
    if (AdmZip) {
      const zip = new AdmZip(archivePath);
      zip.extractAllTo(destDir, true);
    } else {
      execSync(`unzip -o "${archivePath}" -d "${destDir}"`, { stdio: 'inherit' });
    }
  } else if (ext.endsWith('.tar.gz') || ext.endsWith('.tgz')) {
    execSync(`tar -xzf "${archivePath}" -C "${destDir}"`, { stdio: 'inherit' });
  } else {
    fs.copyFileSync(archivePath, path.join(destDir, path.basename(archivePath)));
  }
}

function startBot(botId, config={}) {
  const sid = normalizeBotId(botId);
  if (!sid) return { success:false, message:'Invalid bot id' };
  if (activeBots.has(sid)) return { success:false, message:'Bot already running' };
  const botDir = getBotDirectory(sid);
  if (!botDir || !fs.existsSync(botDir)) return { success:false, message:'Bot files not found' };
  const runtime = resolveRuntime(config.language);
  const entryFull = resolveEntryFile(botDir, config);
  if (!entryFull) return { success:false, message:`No entry file found` };
  const workDir = path.dirname(entryFull);
  const entryFile = path.basename(entryFull);

  if (runtime.key === 'nodejs') {
    const pkg = path.join(workDir, 'package.json');
    const nm = path.join(workDir, 'node_modules');
    if (fs.existsSync(pkg) && !fs.existsSync(nm)) {
      pushLog(sid, config.user_id, 'info', '📦 Installation des dépendances (npm install)...');
      try {
        const out = execSync('npm install --production --no-fund --no-audit 2>&1', { cwd:workDir, timeout:180000 }).toString();
        pushLog(sid, config.user_id, 'info', `✅ npm install terminé:\n${out.slice(0,800)}`);
        setTimeout(() => scanAndStoreBotFiles(sid, getBotDirectory(sid)), 200);
      } catch (e) {
        const msg = e.stdout ? e.stdout.toString() : e.message;
        pushLog(sid, config.user_id, 'error', `❌ npm install échoué:\n${msg.slice(0,1000)}`);
        return { success:false, message:`npm install échoué: ${msg.slice(0,200)}` };
      }
    }
    if (fs.existsSync(pkg)) {
      try {
        const p = JSON.parse(fs.readFileSync(pkg,'utf8'));
        if (p.type==='module' && fs.existsSync(path.join(workDir,entryFile)) && fs.readFileSync(path.join(workDir,entryFile),'utf8').includes('require(')) {
          delete p.type; fs.writeFileSync(pkg, JSON.stringify(p,null,2));
        }
      } catch {}
    }
  }

  const child = spawn(runtime.command, [entryFile], { cwd:workDir, env:buildProcessEnv(config.env_vars,workDir), stdio:['ignore','pipe','pipe'] });
  const startedAt = Date.now();
  child.stdout.on('data', d => { const m=d.toString().trim(); if(m) pushLog(sid, config.user_id,'info',m.startsWith('data:')?m:stripAnsi(m)); });
  child.stderr.on('data', d => { const m=d.toString().trim(); if(m) pushLog(sid, config.user_id,'error',m.startsWith('data:')?m:stripAnsi(m)); });
  child.on('exit', (code,signal) => {
    activeBots.delete(sid);
    const up=getUptimeSeconds(startedAt);
    const manual=signal==='SIGTERM'||signal==='SIGKILL'||code===0;
    if(manual){ updateBotStatus(sid,'stopped',{uptime_seconds:up}); return; }
    pushLog(sid,config.user_id,'warn',`Bot arrêté inopinément (code ${code??signal}). Redémarrez-le manuellement.`);
    updateBotStatus(sid,'error',{uptime_seconds:up});
  });
  activeBots.set(sid, { process:child, startedAt, entryFile, userId:config.user_id, config });
  pushLog(sid, config.user_id, 'info', `Bot démarré avec ${entryFile}`);
  updateBotStatus(sid, 'online', { last_started_at:new Date(startedAt).toISOString(), uptime_seconds:0 });
  return { success:true, message:`Bot started with ${entryFile}` };
}

function stopBot(botId) {
  const sid = normalizeBotId(botId);
  const bot = activeBots.get(sid);
  if (!bot) return { success:false, message:'Bot not found' };
  bot.process.kill('SIGTERM');
  setTimeout(() => { if(!activeBots.has(sid))return; bot.process.kill('SIGKILL'); activeBots.delete(sid); updateBotStatus(sid,'stopped',{uptime_seconds:getUptimeSeconds(bot.startedAt)}); }, 5000).unref();
  return { success:true, message:'Stop signal sent' };
}

function getBotMetrics(pid) {
  try {
    const out=execSync(`ps -o %cpu,rss -p ${pid} --no-headers 2>/dev/null`,{timeout:5000}).toString().trim().split(/\s+/);
    if(out.length<2)return null;
    return {cpu:parseFloat(out[0])||0, ram:parseInt(out[1],10)/1024||0};
  } catch { return null; }
}

setInterval(() => {
  if (!db) return;
  for (const [sid, botData] of activeBots.entries()) {
    const pid = botData.process?.pid;
    if (!pid) continue;
    const m = getBotMetrics(pid);
    if (!m) continue;
    updateBotStatus(sid, 'online', { cpu_usage:Math.round(m.cpu*10)/10, ram_usage:Math.round(m.ram*10)/10, uptime_seconds:getUptimeSeconds(botData.startedAt) });
  }
}, 30000);

// ─── Express app ──────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '100mb' }));
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

function authMiddleware(req, res, next) {
  if (!db) return res.status(503).json({ error: 'Base de données non disponible' });
  const token = (req.headers.authorization || '').replace('Bearer ', '').trim();
  if (!token) return res.status(401).json({ error: 'Non authentifié' });
  const payload = verifyToken(token);
  if (!payload) return res.status(401).json({ error: 'Token invalide ou expiré' });
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(payload.userId);
  if (!user) return res.status(401).json({ error: 'Utilisateur introuvable' });
  req.userId = user.id;
  req.user = user;
  next();
}

function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Accès refusé' });
  next();
}

// ─── Auth routes ──────────────────────────────────────────────────────────────
app.post('/api/auth/register', (req, res) => {
  if (!db) return res.status(503).json({ error: 'Base de données non disponible' });
  const { email, password, name } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email et mot de passe requis' });
  if (password.length < 6) return res.status(400).json({ error: 'Mot de passe trop court (6 caractères min)' });
  const existing = db.prepare('SELECT id FROM users WHERE email=?').get(email.toLowerCase().trim());
  if (existing) return res.status(400).json({ error: 'Cet email est déjà utilisé' });
  const id = genId();
  const hash = hashPassword(password);
  const isFirst = !db.prepare('SELECT id FROM users LIMIT 1').get();
  const role = isFirst ? 'admin' : 'user';
  db.prepare('INSERT INTO users(id,email,password_hash,name,role) VALUES(?,?,?,?,?)').run(id, email.toLowerCase().trim(), hash, name||email.split('@')[0], role);
  db.prepare('INSERT INTO subscriptions(id,user_id,plan,ram_limit) VALUES(?,?,?,?)').run(genId(), id, 'free', 308);
  const user = db.prepare('SELECT id,email,name,role,created_at FROM users WHERE id=?').get(id);
  res.json({ token: signToken(id), user });
});

app.post('/api/auth/login', (req, res) => {
  if (!db) return res.status(503).json({ error: 'Base de données non disponible' });
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email et mot de passe requis' });
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email.toLowerCase().trim());
  if (!user || !checkPassword(password, user.password_hash)) return res.status(401).json({ error: 'Email ou mot de passe incorrect' });
  const { password_hash, ...safe } = user;
  res.json({ token: signToken(user.id), user: safe });
});

app.get('/api/auth/me', authMiddleware, (req, res) => {
  const { password_hash, ...safe } = req.user;
  res.json(safe);
});

app.put('/api/auth/profile', authMiddleware, (req, res) => {
  const { name, email } = req.body || {};
  if (!name?.trim() && !email?.trim()) return res.status(400).json({ error: 'Aucune donnée fournie' });
  if (email && email.toLowerCase() !== req.user.email) {
    const dup = db.prepare('SELECT id FROM users WHERE email=? AND id!=?').get(email.toLowerCase(), req.userId);
    if (dup) return res.status(409).json({ error: 'Cet email est déjà utilisé par un autre compte' });
  }
  const updates = []; const params = [];
  if (name?.trim()) { updates.push('name=?'); params.push(name.trim()); }
  if (email?.trim()) { updates.push('email=?'); params.push(email.trim().toLowerCase()); }
  params.push(req.userId);
  db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id=?`).run(...params);
  const updated = db.prepare('SELECT id,email,name,role,created_at FROM users WHERE id=?').get(req.userId);
  res.json(updated);
});

app.put('/api/auth/password', authMiddleware, (req, res) => {
  const { current_password, new_password } = req.body || {};
  if (!current_password || !new_password) return res.status(400).json({ error: 'Mot de passe actuel et nouveau requis' });
  if (new_password.length < 6) return res.status(400).json({ error: 'Le nouveau mot de passe doit faire au moins 6 caractères' });
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.userId);
  if (!checkPassword(current_password, user.password_hash)) return res.status(401).json({ error: 'Mot de passe actuel incorrect' });
  db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(hashPassword(new_password), req.userId);
  res.json({ success: true });
});

// ─── Bot routes ───────────────────────────────────────────────────────────────
app.get('/api/bots', authMiddleware, (req, res) => {
  res.json(db.prepare('SELECT * FROM bots WHERE user_id=? ORDER BY created_at DESC').all(req.userId).map(normalizeBot));
});

app.post('/api/bots', authMiddleware, (req, res) => {
  const { name, description, platform, language, source_type, source_url, env_vars, file_base64 } = req.body;
  if (!name) return res.status(400).json({ error: 'Nom requis' });
  const id = genId();
  const envJson = JSON.stringify(typeof env_vars === 'object' ? env_vars : {});
  db.prepare('INSERT INTO bots(id,user_id,name,description,platform,language,source_type,source_url,env_vars) VALUES(?,?,?,?,?,?,?,?,?)').run(id,req.userId,name.trim(),description||'',platform||'discord',language||'nodejs',source_type||'upload',source_url||null,envJson);

  if (file_base64) {
    try {
      const botDir = getBotDirectory(id);
      fs.mkdirSync(botDir, { recursive: true });
      const tmpZip = path.join(BOTS_DIR, `_tmp_${id}.zip`);
      fs.writeFileSync(tmpZip, Buffer.from(file_base64, 'base64'));
      extractArchive(tmpZip, botDir);
      if (fs.existsSync(tmpZip)) fs.unlinkSync(tmpZip);
      const items = fs.readdirSync(botDir);
      if (items.length === 1) {
        const sub = path.join(botDir, items[0]);
        if (fs.statSync(sub).isDirectory()) {
          for (const f of fs.readdirSync(sub)) fs.renameSync(path.join(sub,f), path.join(botDir,f));
          fs.rmdirSync(sub);
        }
      }
      setTimeout(() => scanAndStoreBotFiles(id, botDir), 500);
    } catch (e) {
      console.error('[upload] Error:', e.message);
      return res.status(400).json({ error: `Erreur d'extraction: ${e.message}` });
    }
  }

  res.json(normalizeBot(db.prepare('SELECT * FROM bots WHERE id=?').get(id)));
});

app.get('/api/bots/:id', authMiddleware, (req, res) => {
  const bot = db.prepare('SELECT * FROM bots WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable' });
  res.json(normalizeBot(bot));
});

app.put('/api/bots/:id', authMiddleware, (req, res) => {
  const bot = db.prepare('SELECT id FROM bots WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable' });
  const { name, description, platform, language, source_url, env_vars, file_base64 } = req.body;
  const envJson = env_vars ? JSON.stringify(env_vars) : undefined;
  const fields = { updated_at: new Date().toISOString() };
  if (name) fields.name = name;
  if (description !== undefined) fields.description = description;
  if (platform) fields.platform = platform;
  if (language) fields.language = language;
  if (source_url !== undefined) fields.source_url = source_url;
  if (envJson) fields.env_vars = envJson;
  const sets = Object.keys(fields).map(k=>`${k}=?`).join(',');
  db.prepare(`UPDATE bots SET ${sets} WHERE id=?`).run(...Object.values(fields), req.params.id);

  if (file_base64) {
    try {
      const botDir = getBotDirectory(req.params.id);
      if (fs.existsSync(botDir)) fs.rmSync(botDir, { recursive:true });
      fs.mkdirSync(botDir, { recursive:true });
      const tmpZip = path.join(BOTS_DIR, `_tmp_${req.params.id}.zip`);
      fs.writeFileSync(tmpZip, Buffer.from(file_base64, 'base64'));
      extractArchive(tmpZip, botDir);
      if (fs.existsSync(tmpZip)) fs.unlinkSync(tmpZip);
      setTimeout(() => scanAndStoreBotFiles(req.params.id, botDir), 500);
    } catch (e) { return res.status(400).json({ error: e.message }); }
  }

  res.json(normalizeBot(db.prepare('SELECT * FROM bots WHERE id=?').get(req.params.id)));
});

app.delete('/api/bots/:id', authMiddleware, (req, res) => {
  const bot = db.prepare('SELECT id FROM bots WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable' });
  stopBot(req.params.id);
  const botDir = getBotDirectory(req.params.id);
  if (botDir && fs.existsSync(botDir)) try { fs.rmSync(botDir, { recursive:true }); } catch {}
  db.prepare('DELETE FROM bots WHERE id=?').run(req.params.id);
  res.json({ success: true });
});

app.post('/api/bots/:id/start', authMiddleware, (req, res) => {
  const bot = db.prepare('SELECT * FROM bots WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable' });

  const sub = db.prepare('SELECT ram_limit FROM subscriptions WHERE user_id=?').get(req.userId);
  const ramLimit = sub?.ram_limit || 308;
  let totalRam = 0;
  for (const [sid, bd] of activeBots.entries()) {
    if (bd.userId === req.userId) { const m = getBotMetrics(bd.process?.pid); if (m) totalRam += m.ram; }
  }
  if (totalRam >= ramLimit) {
    pushLog(req.params.id, req.userId, 'error', `Limite RAM atteinte (${Math.round(totalRam)}/${ramLimit} MB).`);
    updateBotStatus(req.params.id, 'error');
    return res.status(400).json({ error: `Limite RAM atteinte (${Math.round(totalRam)}/${ramLimit} MB)` });
  }

  const botDir = getBotDirectory(req.params.id);
  const hasFiles = botDir && fs.existsSync(botDir) && fs.readdirSync(botDir).filter(f=>!f.startsWith('_tmp_')).length > 0;

  if (!hasFiles && normalizeBot(bot).source_type === 'url' && bot.source_url) {
    updateBotStatus(req.params.id, 'deploying');
    try {
      fs.mkdirSync(botDir, { recursive: true });
      const tmpFile = path.join(BOTS_DIR, `_dl_${req.params.id}.zip`);
      execSync(`curl -fsSL -o "${tmpFile}" "${bot.source_url}"`, { timeout: 60000 });
      extractArchive(tmpFile, botDir);
      if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile);
      const items = fs.readdirSync(botDir);
      if (items.length === 1) {
        const sub2 = path.join(botDir, items[0]);
        if (fs.statSync(sub2).isDirectory()) {
          for (const f of fs.readdirSync(sub2)) fs.renameSync(path.join(sub2,f), path.join(botDir,f));
          fs.rmdirSync(sub2);
        }
      }
      scanAndStoreBotFiles(req.params.id, botDir);
    } catch (e) {
      updateBotStatus(req.params.id, 'error');
      return res.status(400).json({ error: `Erreur téléchargement: ${e.message}` });
    }
  }

  applyModifiedFiles(req.params.id, botDir);
  const nbotRow = normalizeBot(bot);
  const result = startBot(req.params.id, { language: nbotRow.language, env_vars: nbotRow.env_vars, user_id: req.userId });
  if (!result.success) {
    updateBotStatus(req.params.id, 'error');
    return res.status(400).json({ error: result.message });
  }
  res.json({ success: true, message: result.message });
});

app.post('/api/bots/:id/stop', authMiddleware, (req, res) => {
  const bot = db.prepare('SELECT id FROM bots WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable' });
  const result = stopBot(req.params.id);
  res.json(result);
});

app.post('/api/bots/:id/restart', authMiddleware, (req, res) => {
  const bot = db.prepare('SELECT * FROM bots WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable' });
  stopBot(req.params.id);
  setTimeout(() => {
    applyModifiedFiles(req.params.id, getBotDirectory(req.params.id));
    const nb = normalizeBot(bot);
    startBot(req.params.id, { language: nb.language, env_vars: nb.env_vars, user_id: req.userId });
  }, 2000);
  res.json({ success: true, message: 'Redémarrage en cours...' });
});

// ─── Bot files routes ─────────────────────────────────────────────────────────
app.get('/api/bots/:id/files', authMiddleware, (req, res) => {
  const bot = db.prepare('SELECT id FROM bots WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable' });
  res.json(db.prepare('SELECT * FROM bot_files WHERE bot_id=? ORDER BY path').all(bot.id));
});

app.post('/api/bots/:id/files/sync', authMiddleware, (req, res) => {
  const bot = db.prepare('SELECT id FROM bots WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!bot) return res.status(404).json({ error: 'Bot introuvable' });
  const botDir = getBotDirectory(bot.id);
  if (!botDir || !fs.existsSync(botDir)) return res.status(400).json({ error: 'Répertoire bot introuvable' });
  scanAndStoreBotFiles(bot.id, botDir);
  const files = db.prepare('SELECT * FROM bot_files WHERE bot_id=? ORDER BY path').all(bot.id);
  res.json({ synced: files.length, files });
});

app.post('/api/bots/:id/files', authMiddleware, (req, res) => {
  const { path: filePath, content } = req.body;
  if (!filePath) return res.status(400).json({ error: 'Chemin requis' });
  const id = genId();
  db.prepare('INSERT OR REPLACE INTO bot_files(id,bot_id,user_id,path,content,is_modified) VALUES(?,?,?,?,?,1)').run(id, req.params.id, req.userId, filePath, content||'');
  res.json(db.prepare('SELECT * FROM bot_files WHERE id=?').get(id));
});

app.put('/api/bots/:id/files/:fileId', authMiddleware, (req, res) => {
  const { content, is_modified } = req.body;
  db.prepare("UPDATE bot_files SET content=?,is_modified=?,updated_at=datetime('now') WHERE id=? AND bot_id=?").run(content||'', is_modified?1:0, req.params.fileId, req.params.id);
  res.json(db.prepare('SELECT * FROM bot_files WHERE id=?').get(req.params.fileId));
});

app.delete('/api/bots/:id/files/:fileId', authMiddleware, (req, res) => {
  db.prepare('DELETE FROM bot_files WHERE id=? AND bot_id=?').run(req.params.fileId, req.params.id);
  res.json({ success: true });
});

// ─── Logs routes ──────────────────────────────────────────────────────────────
app.get('/api/bots/:id/logs', authMiddleware, (req, res) => {
  const limit = Math.min(parseInt(req.query.limit)||200, 1000);
  const logs = db.prepare('SELECT * FROM bot_logs WHERE bot_id=? ORDER BY created_at DESC LIMIT ?').all(req.params.id, limit);
  res.json(logs.reverse());
});

app.get('/api/logs', authMiddleware, (req, res) => {
  const limit = Math.min(parseInt(req.query.limit)||200, 1000);
  const logs = db.prepare('SELECT bl.* FROM bot_logs bl JOIN bots b ON b.id=bl.bot_id WHERE b.user_id=? ORDER BY bl.created_at DESC LIMIT ?').all(req.userId, limit);
  res.json(logs.reverse());
});

// ─── Subscription routes ──────────────────────────────────────────────────────
app.get('/api/subscription', authMiddleware, (req, res) => {
  let sub = db.prepare('SELECT * FROM subscriptions WHERE user_id=?').get(req.userId);
  if (!sub) {
    db.prepare('INSERT INTO subscriptions(id,user_id,plan,ram_limit) VALUES(?,?,?,?)').run(genId(),req.userId,'free',308);
    sub = db.prepare('SELECT * FROM subscriptions WHERE user_id=?').get(req.userId);
  }
  res.json(sub);
});

app.post('/api/subscription/activate', authMiddleware, (req, res) => {
  const PLAN_LIMITS = { free:308, standard:700, pro:1024, business:4096 };
  const { plan } = req.body;
  if (!plan || !PLAN_LIMITS[plan]) return res.status(400).json({ error: 'Plan invalide' });
  const ram = PLAN_LIMITS[plan];
  const existing = db.prepare('SELECT id FROM subscriptions WHERE user_id=?').get(req.userId);
  if (existing) {
    db.prepare('UPDATE subscriptions SET plan=?,ram_limit=? WHERE user_id=?').run(plan, ram, req.userId);
  } else {
    db.prepare('INSERT INTO subscriptions(id,user_id,plan,ram_limit) VALUES(?,?,?,?)').run(genId(), req.userId, plan, ram);
  }
  res.json(db.prepare('SELECT * FROM subscriptions WHERE user_id=?').get(req.userId));
});

// ─── Credits routes ──────────────────────────────────────────────────────────
function getOrCreateCredits(userId) {
  let c = db.prepare('SELECT * FROM credits WHERE user_id=?').get(userId);
  if (!c) {
    db.prepare('INSERT INTO credits(id,user_id,balance) VALUES(?,?,0)').run(genId(), userId);
    c = db.prepare('SELECT * FROM credits WHERE user_id=?').get(userId);
  }
  return c;
}
function addTransaction(userId, amount, type, description, reference) {
  db.prepare('INSERT INTO credit_transactions(id,user_id,amount,type,description,reference) VALUES(?,?,?,?,?,?)')
    .run(genId(), userId, amount, type, description, reference || null);
}

const CREDIT_PACKS = {
  starter:  { credits: 500,  price: 5,  label: 'Pack Starter — 500 crédits (5€)' },
  standard: { credits: 1100, price: 10, label: 'Pack Standard — 1100 crédits (10€)' },
  pro:      { credits: 2800, price: 25, label: 'Pack Pro — 2800 crédits (25€)' },
  max:      { credits: 6000, price: 50, label: 'Pack Max — 6000 crédits (50€)' },
};

app.get('/api/credits', authMiddleware, (req, res) => {
  const credits = getOrCreateCredits(req.userId);
  const transactions = db.prepare('SELECT * FROM credit_transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(req.userId);
  res.json({ ...credits, transactions });
});

app.post('/api/credits/purchase', authMiddleware, (req, res) => {
  const { pack } = req.body || {};
  const chosen = CREDIT_PACKS[pack];
  if (!chosen) return res.status(400).json({ error: 'Pack invalide' });
  getOrCreateCredits(req.userId);
  db.prepare('UPDATE credits SET balance=balance+?, updated_at=datetime(\'now\') WHERE user_id=?').run(chosen.credits, req.userId);
  addTransaction(req.userId, chosen.credits, 'purchase', chosen.label);
  res.json(db.prepare('SELECT * FROM credits WHERE user_id=?').get(req.userId));
});

app.post('/api/credits/soleaspay-confirm', authMiddleware, (req, res) => {
  const { pack, order_id, pay_id } = req.body || {};
  const chosen = CREDIT_PACKS[pack];
  if (!chosen) return res.status(400).json({ error: 'Pack invalide' });
  if (!order_id) return res.status(400).json({ error: 'order_id manquant' });
  const existing = db.prepare('SELECT id FROM credit_transactions WHERE user_id=? AND reference=?').get(req.userId, order_id);
  if (existing) return res.status(409).json({ error: 'Ce paiement a déjà été crédité' });
  getOrCreateCredits(req.userId);
  db.prepare('UPDATE credits SET balance=balance+?, updated_at=datetime(\'now\') WHERE user_id=?').run(chosen.credits, req.userId);
  const label = `${chosen.label} — SoleasPay ref: ${pay_id || order_id}`;
  addTransaction(req.userId, chosen.credits, 'purchase', label, order_id);
  const updated = db.prepare('SELECT * FROM credits WHERE user_id=?').get(req.userId);
  res.json({ ...updated, credited: chosen.credits });
});

// Proxy SoleasPay — initiation paiement (évite CORS côté navigateur)
app.post('/api/credits/soleaspay-initiate', authMiddleware, async (req, res) => {
  try {
    const { wallet, amount, currency, order_id, description, payer, payerEmail, service, otp } = req.body || {};
    const headers = {
      'Content-Type': 'application/json',
      'x-api-key': SOLEASPAY_API_KEY,
      'operation': '2',
      'service': String(service),
    };
    if (otp) headers['otp'] = otp;
    const spRes = await fetch(`${SOLEASPAY_BASE}/api/agent/bills/v3`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ wallet, amount, currency, order_id, description, payer, payerEmail }),
    });
    const data = await spRes.json().catch(() => ({}));
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: e?.message || 'Erreur SoleasPay' });
  }
});

// Proxy SoleasPay — vérification paiement
app.get('/api/credits/soleaspay-verify', authMiddleware, async (req, res) => {
  try {
    const { orderId, payId, service } = req.query;
    const url = `${SOLEASPAY_BASE}/api/agent/verif-pay?orderId=${encodeURIComponent(orderId)}&payId=${encodeURIComponent(payId)}`;
    const spRes = await fetch(url, {
      method: 'GET',
      headers: { 'x-api-key': SOLEASPAY_API_KEY, 'operation': '2', 'service': String(service) },
    });
    const data = await spRes.json().catch(() => ({}));
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: e?.message || 'Erreur SoleasPay' });
  }
});

app.put('/api/credits/auto-recharge', authMiddleware, (req, res) => {
  const { auto_recharge, auto_recharge_threshold, auto_recharge_amount } = req.body || {};
  getOrCreateCredits(req.userId);
  db.prepare('UPDATE credits SET auto_recharge=?, auto_recharge_threshold=?, auto_recharge_amount=?, updated_at=datetime(\'now\') WHERE user_id=?')
    .run(auto_recharge ? 1 : 0, auto_recharge_threshold ?? 100, auto_recharge_amount ?? 500, req.userId);
  res.json(db.prepare('SELECT * FROM credits WHERE user_id=?').get(req.userId));
});

app.post('/api/credits/spend', authMiddleware, (req, res) => {
  const { amount, description } = req.body || {};
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Montant invalide' });
  const credits = getOrCreateCredits(req.userId);
  if (credits.balance < amount) {
    if (credits.auto_recharge && credits.balance + credits.auto_recharge_amount >= amount) {
      db.prepare('UPDATE credits SET balance=balance+?, updated_at=datetime(\'now\') WHERE user_id=?').run(credits.auto_recharge_amount, req.userId);
      addTransaction(req.userId, credits.auto_recharge_amount, 'auto_recharge', `Recharge automatique de ${credits.auto_recharge_amount} crédits`);
    } else {
      return res.status(400).json({ error: 'Solde insuffisant' });
    }
  }
  db.prepare('UPDATE credits SET balance=balance-?, updated_at=datetime(\'now\') WHERE user_id=?').run(amount, req.userId);
  addTransaction(req.userId, -amount, 'spend', description || 'Dépense de crédits');
  res.json(db.prepare('SELECT * FROM credits WHERE user_id=?').get(req.userId));
});

// ─── Domain routes ─────────────────────────────────────────────────────────────
app.get('/api/domains', authMiddleware, (req, res) => {
  res.json(db.prepare('SELECT * FROM domains WHERE user_id=? ORDER BY created_at DESC').all(req.userId));
});

app.post('/api/domains', authMiddleware, (req, res) => {
  const { name, tld, expires_at } = req.body;
  if (!name) return res.status(400).json({ error: 'Nom requis' });
  const id = genId();
  db.prepare('INSERT INTO domains(id,user_id,name,tld,expires_at) VALUES(?,?,?,?,?)').run(id,req.userId,name.trim().toLowerCase(),tld||'.com',expires_at||null);
  res.json(db.prepare('SELECT * FROM domains WHERE id=?').get(id));
});

app.delete('/api/domains/:id', authMiddleware, (req, res) => {
  db.prepare('DELETE FROM domains WHERE id=? AND user_id=?').run(req.params.id, req.userId);
  res.json({ success: true });
});

app.get('/api/domains/:id/records', authMiddleware, (req, res) => {
  res.json(db.prepare('SELECT * FROM dns_records WHERE domain_id=? ORDER BY created_at').all(req.params.id));
});

app.post('/api/domains/:id/records', authMiddleware, (req, res) => {
  const { type, name, value, ttl } = req.body;
  if (!type || !name || !value) return res.status(400).json({ error: 'type, name et value requis' });
  const id = genId();
  db.prepare('INSERT INTO dns_records(id,domain_id,user_id,type,name,value,ttl) VALUES(?,?,?,?,?,?,?)').run(id,req.params.id,req.userId,type,name,value,ttl||3600);
  res.json(db.prepare('SELECT * FROM dns_records WHERE id=?').get(id));
});

app.delete('/api/domains/:id/records/:recordId', authMiddleware, (req, res) => {
  db.prepare('DELETE FROM dns_records WHERE id=? AND domain_id=?').run(req.params.recordId, req.params.id);
  res.json({ success: true });
});

// ─── DNS Manager pour domain_orders (livrés) ─────────────────────────────────
// Vérifie que la commande appartient à l'utilisateur ET est livrée
app.get('/api/domain-orders/:id/records', authMiddleware, (req, res) => {
  const order = db.prepare('SELECT * FROM domain_orders WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!order) return res.status(404).json({ error: 'Commande introuvable' });
  if (order.status !== 'delivered') return res.status(403).json({ error: 'Domaine pas encore livré' });
  res.json(db.prepare('SELECT * FROM dns_records WHERE domain_id=? ORDER BY created_at').all(req.params.id));
});

app.post('/api/domain-orders/:id/records', authMiddleware, async (req, res) => {
  const order = db.prepare('SELECT * FROM domain_orders WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!order) return res.status(404).json({ error: 'Commande introuvable' });
  if (order.status !== 'delivered') return res.status(403).json({ error: 'Domaine pas encore livré' });
  const { type, name, value, ttl } = req.body;
  if (!type || !name || !value) return res.status(400).json({ error: 'type, name et value requis' });

  // Enregistrement local
  const id = genId();
  db.prepare('INSERT INTO dns_records(id,domain_id,user_id,type,name,value,ttl) VALUES(?,?,?,?,?,?,?)').run(id, req.params.id, req.userId, type, name.trim(), value.trim(), ttl || 3600);

  // Push automatique sur Hostinger
  let hostingerSync = { success: false, message: 'HOSTINGER_API_KEY non configuré' };
  if (process.env.HOSTINGER_API_KEY) {
    const hResult = await hostingerAddRecord(order.domain, type, name.trim(), value.trim(), ttl || 300);
    if (hResult.data) {
      const hId = hResult.data.id ? String(hResult.data.id) : null;
      if (hId) db.prepare('UPDATE dns_records SET hostinger_record_id=? WHERE id=?').run(hId, id);
      hostingerSync = { success: true, hostinger_id: hId };
    } else {
      hostingerSync = { success: false, message: hResult.error || 'Erreur Hostinger' };
    }
  }

  const record = db.prepare('SELECT * FROM dns_records WHERE id=?').get(id);
  res.json({ ...record, hostinger_sync: hostingerSync });
});

app.delete('/api/domain-orders/:id/records/:recordId', authMiddleware, async (req, res) => {
  const order = db.prepare('SELECT * FROM domain_orders WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!order) return res.status(404).json({ error: 'Commande introuvable' });

  // Récupérer l'ID Hostinger avant suppression
  const record = db.prepare('SELECT * FROM dns_records WHERE id=? AND domain_id=?').get(req.params.recordId, req.params.id);

  // Suppression locale
  db.prepare('DELETE FROM dns_records WHERE id=? AND domain_id=?').run(req.params.recordId, req.params.id);

  // Suppression sur Hostinger si on a l'ID
  let hostingerSync = { success: false };
  if (process.env.HOSTINGER_API_KEY && record?.hostinger_record_id) {
    const hResult = await hostingerDeleteRecord(order.domain, record.hostinger_record_id);
    hostingerSync = hResult.data !== undefined ? { success: true } : { success: false, message: hResult.error };
  }

  res.json({ success: true, hostinger_sync: hostingerSync });
});

// ─── Hosting web routes ───────────────────────────────────────────────────────
const BASE_HOSTING_DOMAIN = 'bothoster.sbs';

app.get('/api/hosting/sites', authMiddleware, (req, res) => {
  const sites = db.prepare('SELECT * FROM web_sites WHERE user_id=? ORDER BY created_at DESC').all(req.userId);
  res.json(sites);
});

app.post('/api/hosting/sites', authMiddleware, async (req, res) => {
  const { name, subdomain, custom_domain, stack, github_url } = req.body;
  if (!name || !subdomain) return res.status(400).json({ error: 'name et subdomain requis' });

  // Vérifier unicité
  const existing = db.prepare('SELECT id FROM web_sites WHERE subdomain=?').get(subdomain);
  if (existing) return res.status(409).json({ error: `Le sous-domaine "${subdomain}.${BASE_HOSTING_DOMAIN}" est déjà pris` });

  const id = genId();
  db.prepare('INSERT INTO web_sites(id,user_id,name,subdomain,custom_domain,stack,status,github_url) VALUES(?,?,?,?,?,?,?,?)')
    .run(id, req.userId, name.trim(), subdomain.trim(), custom_domain || null, stack || 'HTML / CSS', 'deploying', github_url || null);

  // Créer A record sur Hostinger si VPS_IP configuré
  let hostingerSync = { success: false, message: 'VPS_IP ou HOSTINGER_API_KEY non configuré' };
  if (process.env.HOSTINGER_API_KEY && VPS_IP) {
    const hResult = await hostingerAddRecord(BASE_HOSTING_DOMAIN, 'A', subdomain.trim(), VPS_IP, 300);
    if (hResult.data) {
      const hId = hResult.data.id ? String(hResult.data.id) : null;
      if (hId) db.prepare('UPDATE web_sites SET hostinger_record_id=? WHERE id=?').run(hId, id);
      hostingerSync = { success: true, hostinger_id: hId };
    } else {
      hostingerSync = { success: false, message: hResult.error || 'Erreur Hostinger' };
    }
  }

  const site = db.prepare('SELECT * FROM web_sites WHERE id=?').get(id);
  // Simuler passage en "online" — en prod le déploiement réel doit changer ce statut
  db.prepare('UPDATE web_sites SET status=? WHERE id=?').run('online', id);
  res.json({ ...site, status: 'online', full_domain: `${subdomain}.${BASE_HOSTING_DOMAIN}`, hostinger_sync: hostingerSync });
});

app.delete('/api/hosting/sites/:id', authMiddleware, async (req, res) => {
  const site = db.prepare('SELECT * FROM web_sites WHERE id=? AND user_id=?').get(req.params.id, req.userId);
  if (!site) return res.status(404).json({ error: 'Site introuvable' });

  // Supprimer le DNS Hostinger
  let hostingerSync = { success: false };
  if (process.env.HOSTINGER_API_KEY && site.hostinger_record_id) {
    const hResult = await hostingerDeleteRecord(BASE_HOSTING_DOMAIN, site.hostinger_record_id);
    hostingerSync = hResult.data !== undefined ? { success: true } : { success: false, message: hResult.error };
  }

  db.prepare('DELETE FROM web_sites WHERE id=?').run(req.params.id);
  res.json({ success: true, hostinger_sync: hostingerSync });
});

// ─── Admin routes ─────────────────────────────────────────────────────────────
app.get('/api/admin/users', authMiddleware, adminOnly, (req, res) => {
  const users = db.prepare('SELECT u.id,u.email,u.name,u.role,u.created_at,s.plan,s.ram_limit FROM users u LEFT JOIN subscriptions s ON s.user_id=u.id ORDER BY u.created_at DESC').all();
  res.json(users);
});

app.get('/api/admin/stats', authMiddleware, adminOnly, (req, res) => {
  const userCount = (db.prepare('SELECT COUNT(*) as c FROM users').get() || {}).c || 0;
  const botCount = (db.prepare('SELECT COUNT(*) as c FROM bots').get() || {}).c || 0;
  const onlineCount = (db.prepare("SELECT COUNT(*) as c FROM bots WHERE status='online'").get() || {}).c || 0;
  res.json({ userCount, botCount, onlineCount, activeBots: activeBots.size });
});

app.patch('/api/admin/users/:id/subscription', authMiddleware, adminOnly, (req, res) => {
  const PLAN_RAM = { free:308, standard:700, pro:1024, business:4096 };
  const { plan, ram_limit } = req.body;
  const ram = ram_limit || PLAN_RAM[plan] || 308;
  const existing = db.prepare('SELECT id FROM subscriptions WHERE user_id=?').get(req.params.id);
  if (existing) {
    db.prepare('UPDATE subscriptions SET plan=?,ram_limit=? WHERE user_id=?').run(plan||'free',ram,req.params.id);
  } else {
    db.prepare('INSERT INTO subscriptions(id,user_id,plan,ram_limit) VALUES(?,?,?,?)').run(genId(),req.params.id,plan||'free',ram);
  }
  res.json({ success: true });
});

app.post('/api/admin/credits/give', authMiddleware, adminOnly, (req, res) => {
  const { user_id, amount, description } = req.body || {};
  if (!user_id || !amount || amount <= 0) return res.status(400).json({ error: 'user_id et amount requis' });
  const target = db.prepare('SELECT id FROM users WHERE id=?').get(user_id);
  if (!target) return res.status(404).json({ error: 'Utilisateur introuvable' });
  getOrCreateCredits(user_id);
  db.prepare('UPDATE credits SET balance=balance+?, updated_at=datetime(\'now\') WHERE user_id=?').run(amount, user_id);
  addTransaction(user_id, amount, 'admin_gift', description || `Crédits offerts par l'admin (${amount})`);
  res.json(db.prepare('SELECT * FROM credits WHERE user_id=?').get(user_id));
});

// ─── Domain orders routes ─────────────────────────────────────────────────────
const NS1_DOMAIN = 'ns1.bothoster.com';
const NS2_DOMAIN = 'ns2.bothoster.com';

function genCmdId() {
  return 'CMD' + Math.floor(100000 + Math.random() * 900000);
}

// Check availability (simulated via Google DNS)
app.get('/api/domains/check', async (req, res) => {
  const domain = (req.query.domain || '').trim().toLowerCase();
  if (!domain) return res.status(400).json({ error: 'Domaine requis' });
  try {
    const { default: https } = await import('https');
    const url = `https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=A`;
    const data = await new Promise((resolve, reject) => {
      https.get(url, r => {
        let body = '';
        r.on('data', d => body += d);
        r.on('end', () => { try { resolve(JSON.parse(body)); } catch { reject(new Error('parse error')); } });
      }).on('error', reject);
    });
    res.json({ domain, available: !data.Answer || data.Answer.length === 0 });
  } catch {
    res.json({ domain, available: null, error: 'Vérification impossible' });
  }
});

// Create a domain order (public or authenticated)
app.post('/api/domain-orders', (req, res) => {
  if (!db) return res.status(503).json({ error: 'Base de données non disponible' });
  const { domain, client_name, client_email } = req.body;
  if (!domain || !client_name || !client_email) return res.status(400).json({ error: 'domain, client_name et client_email requis' });

  const token = (req.headers.authorization || '').replace('Bearer ', '').trim();
  let userId = null;
  if (token && jwt) {
    try { userId = jwt.verify(token, JWT_SECRET)?.userId || null; } catch {}
  }

  let cmdId = genCmdId();
  // Ensure unique cmd_id
  let attempts = 0;
  while (db.prepare('SELECT id FROM domain_orders WHERE cmd_id=?').get(cmdId) && attempts < 10) {
    cmdId = genCmdId(); attempts++;
  }

  const id = genId();
  db.prepare('INSERT INTO domain_orders(id,cmd_id,user_id,domain,client_name,client_email,dns1,dns2,status) VALUES(?,?,?,?,?,?,?,?,?)').run(
    id, cmdId, userId, domain.trim().toLowerCase(), client_name.trim(), client_email.trim().toLowerCase(), NS1_DOMAIN, NS2_DOMAIN, 'pending'
  );
  res.json(db.prepare('SELECT * FROM domain_orders WHERE id=?').get(id));
});

// Get my orders (authenticated)
app.get('/api/domain-orders', authMiddleware, (req, res) => {
  res.json(db.prepare('SELECT * FROM domain_orders WHERE user_id=? ORDER BY created_at DESC').all(req.userId));
});

// Admin: get all orders
app.get('/api/admin/domain-orders', authMiddleware, adminOnly, (req, res) => {
  res.json(db.prepare('SELECT * FROM domain_orders ORDER BY created_at DESC').all());
});

// Admin: mark as delivered
app.patch('/api/admin/domain-orders/:id/deliver', authMiddleware, adminOnly, (req, res) => {
  db.prepare("UPDATE domain_orders SET status='delivered' WHERE id=?").run(req.params.id);
  const order = db.prepare('SELECT * FROM domain_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Commande introuvable' });
  res.json(order);
});

// Admin: update DNS of order
app.patch('/api/admin/domain-orders/:id/dns', authMiddleware, adminOnly, (req, res) => {
  const { dns1, dns2 } = req.body;
  if (!dns1 || !dns2) return res.status(400).json({ error: 'dns1 et dns2 requis' });
  db.prepare("UPDATE domain_orders SET dns1=?, dns2=? WHERE id=?").run(dns1.trim(), dns2.trim(), req.params.id);
  const order = db.prepare('SELECT * FROM domain_orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Commande introuvable' });
  res.json(order);
});

// Admin: delete order
app.delete('/api/admin/domain-orders/:id', authMiddleware, adminOnly, (req, res) => {
  db.prepare('DELETE FROM domain_orders WHERE id=?').run(req.params.id);
  res.json({ success: true });
});

// ─── Admin: download server ZIP ───────────────────────────────────────────────
app.get('/api/admin/download-server-zip', authMiddleware, adminOnly, (req, res) => {
  if (!AdmZip) return res.status(500).json({ error: 'adm-zip non disponible' });
  try {
    const instructions = `
╔══════════════════════════════════════════════════════════════╗
║            BOTHOSTER — INSTRUCTIONS D'INSTALLATION           ║
╚══════════════════════════════════════════════════════════════╝

✅ Ce serveur utilise sql.js (SQLite pur JavaScript).
   Aucune compilation native requise — fonctionne avec Node.js v24 !

═══════════════════════════════════════════════
 ÉTAPE 1 — Sur votre VPS KataBump
═══════════════════════════════════════════════

1. Uploadez ce ZIP sur votre VPS KataBump
2. Dans le terminal KataBump, tapez ces commandes :

   unzip bothoster-server.zip -d bothoster-server
   cd bothoster-server
   npm install
   node index.js

   ✅ Le serveur démarre sur le PORT 3001
   ✅ La base de données (bothoster.db) se crée automatiquement
   ✅ Le premier compte inscrit sera ADMIN

═══════════════════════════════════════════════
 ÉTAPE 2 — Variables d'environnement (IMPORTANT)
═══════════════════════════════════════════════

   Avant de démarrer, créez un fichier .env ou exportez ces variables :

   HOSTINGER_API_KEY=votre_clé_api_hostinger
   VPS_IP=${VPS_IP}                  ← IP publique de ce VPS (déjà configuré)
   JWT_SECRET=une_chaine_secrete_longue
   PORT=3001

   La variable VPS_IP est utilisée pour créer automatiquement les
   sous-domaines bothoster.sbs quand un utilisateur héberge un site.

   Pour charger le .env au démarrage :
   npm install dotenv
   Ajoutez en haut de index.js : require('dotenv').config();

═══════════════════════════════════════════════
 ÉTAPE 3 — Sur Vercel (votre site bothoster.sbs)
═══════════════════════════════════════════════

1. Allez sur https://vercel.com
2. Ouvrez votre projet BotHoster
3. Cliquez sur "Settings" → "Environment Variables"
4. Ajoutez cette variable :

   Nom   : VITE_API_URL
   Valeur: http://VOTRE_IP_KATABUMP:3001

5. Cliquez "Save" puis "Redeploy"

   ✅ Votre site bothoster.sbs est connecté à votre serveur !

═══════════════════════════════════════════════
 ÉTAPE 4 — Garder le serveur actif en permanence
═══════════════════════════════════════════════

   npm install -g pm2
   pm2 start index.js --name bothoster
   pm2 save
   pm2 startup   ← démarre au boot du VPS

═══════════════════════════════════════════════
 SOUS-DOMAINES AUTOMATIQUES (bothoster.sbs)
═══════════════════════════════════════════════

   Quand un utilisateur héberge un site, le serveur crée
   automatiquement un enregistrement DNS A dans Hostinger :

   monsite.bothoster.sbs → VPS_IP

   Requis : HOSTINGER_API_KEY + VPS_IP dans l'environnement
`;
    const zip = new AdmZip();
    zip.addFile('LIRE_MOI.txt', Buffer.from(instructions, 'utf8'));
    zip.addLocalFile(path.join(__dirname, 'index.js'));
    zip.addLocalFile(path.join(__dirname, 'package.json'));
    const buffer = zip.toBuffer();
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="bothoster-server.zip"');
    res.setHeader('Content-Length', buffer.length);
    res.send(buffer);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── Admin: download frontend site ZIP ────────────────────────────────────────
app.get('/api/admin/download-site-zip', authMiddleware, adminOnly, (req, res) => {
  if (!AdmZip) return res.status(500).json({ error: 'adm-zip non disponible' });
  try {
    const fs = require('fs');
    const root = path.join(__dirname, '..');
    const zip = new AdmZip();

    // Ajouter les dossiers source
    const foldersToAdd = ['src', 'public'];
    for (const folder of foldersToAdd) {
      const folderPath = path.join(root, folder);
      if (fs.existsSync(folderPath)) zip.addLocalFolder(folderPath, folder);
    }

    // Ajouter les fichiers de config
    const configFiles = [
      'index.html', 'package.json', 'vite.config.ts',
      'tailwind.config.ts', 'tsconfig.json', 'tsconfig.app.json',
      'postcss.config.js', 'components.json',
    ];
    for (const f of configFiles) {
      const fp = path.join(root, f);
      if (fs.existsSync(fp)) zip.addLocalFile(fp);
    }

    // vercel.json
    const vercelJson = JSON.stringify({ rewrites: [{ source: '/((?!.*\\..*).*)', destination: '/index.html' }] }, null, 2);
    if (fs.existsSync(path.join(root, 'vercel.json'))) {
      zip.addLocalFile(path.join(root, 'vercel.json'));
    } else {
      zip.addFile('vercel.json', Buffer.from(vercelJson, 'utf8'));
    }

    // README de déploiement Vercel
    const readme = `# BotHoster — Site Web (Frontend)

## Déploiement sur Vercel

1. Créez un compte sur https://vercel.com
2. Importez ce projet GitHub ou uploadez ce ZIP
3. Ajoutez la variable d'environnement :
   VITE_API_URL=http://${VPS_IP}:3001
4. Cliquez "Deploy"

Votre site sera disponible sur bothoster.sbs
`;
    zip.addFile('README_VERCEL.md', Buffer.from(readme, 'utf8'));

    const buffer = zip.toBuffer();
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="bothoster-site.zip"');
    res.setHeader('Content-Length', buffer.length);
    res.send(buffer);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', db: !!db, uptime: process.uptime() }));

// ─── Async startup: load sql.js then start server ─────────────────────────────
(async () => {
  if (initSqlJs) {
    try {
      console.log('[db] Chargement de sql.js...');
      const SQL = await initSqlJs();
      const sqliteDB = new SqliteDB(SQL, DB_PATH);
      sqliteDB.pragma('journal_mode = WAL');
      sqliteDB.pragma('foreign_keys = ON');
      sqliteDB.exec(`
        CREATE TABLE IF NOT EXISTS users (
          id TEXT PRIMARY KEY,
          email TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL,
          name TEXT,
          role TEXT DEFAULT 'user',
          created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS bots (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          name TEXT NOT NULL,
          description TEXT,
          platform TEXT DEFAULT 'discord',
          language TEXT DEFAULT 'nodejs',
          status TEXT DEFAULT 'stopped',
          source_type TEXT DEFAULT 'upload',
          source_url TEXT,
          env_vars TEXT DEFAULT '{}',
          cpu_usage REAL DEFAULT 0,
          ram_usage REAL DEFAULT 0,
          uptime_seconds INTEGER DEFAULT 0,
          last_started_at TEXT,
          updated_at TEXT DEFAULT (datetime('now')),
          created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS bot_files (
          id TEXT PRIMARY KEY,
          bot_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          path TEXT NOT NULL,
          content TEXT,
          is_modified INTEGER DEFAULT 0,
          updated_at TEXT DEFAULT (datetime('now')),
          created_at TEXT DEFAULT (datetime('now')),
          UNIQUE(bot_id, path)
        );
        CREATE TABLE IF NOT EXISTS bot_logs (
          id TEXT PRIMARY KEY,
          bot_id TEXT NOT NULL,
          user_id TEXT,
          level TEXT DEFAULT 'info',
          message TEXT,
          created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS subscriptions (
          id TEXT PRIMARY KEY,
          user_id TEXT UNIQUE NOT NULL,
          plan TEXT DEFAULT 'free',
          ram_limit INTEGER DEFAULT 308,
          expires_at TEXT,
          created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS domains (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          name TEXT NOT NULL,
          tld TEXT DEFAULT '.com',
          status TEXT DEFAULT 'active',
          nameserver1 TEXT DEFAULT 'ns1.bothoster.com',
          nameserver2 TEXT DEFAULT 'ns2.bothoster.com',
          expires_at TEXT,
          created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS dns_records (
          id TEXT PRIMARY KEY,
          domain_id TEXT NOT NULL,
          user_id TEXT NOT NULL,
          type TEXT NOT NULL,
          name TEXT NOT NULL,
          value TEXT NOT NULL,
          ttl INTEGER DEFAULT 3600,
          hostinger_record_id TEXT,
          created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS domain_orders (
          id TEXT PRIMARY KEY,
          cmd_id TEXT NOT NULL UNIQUE,
          user_id TEXT,
          domain TEXT NOT NULL,
          client_name TEXT NOT NULL,
          client_email TEXT NOT NULL,
          dns1 TEXT DEFAULT 'ns1.bothoster.com',
          dns2 TEXT DEFAULT 'ns2.bothoster.com',
          status TEXT DEFAULT 'pending',
          created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS web_sites (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          name TEXT NOT NULL,
          subdomain TEXT NOT NULL UNIQUE,
          custom_domain TEXT,
          stack TEXT DEFAULT 'HTML / CSS',
          status TEXT DEFAULT 'deploying',
          github_url TEXT,
          hostinger_record_id TEXT,
          created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS credits (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL UNIQUE,
          balance INTEGER DEFAULT 0,
          auto_recharge INTEGER DEFAULT 0,
          auto_recharge_threshold INTEGER DEFAULT 100,
          auto_recharge_amount INTEGER DEFAULT 500,
          updated_at TEXT DEFAULT (datetime('now')),
          created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS credit_transactions (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          amount INTEGER NOT NULL,
          type TEXT NOT NULL,
          description TEXT,
          reference TEXT,
          created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS support_tickets (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          subject TEXT NOT NULL,
          message TEXT NOT NULL,
          status TEXT DEFAULT 'open',
          reply TEXT,
          created_at TEXT DEFAULT (datetime('now')),
          updated_at TEXT DEFAULT (datetime('now'))
        );
      `);
      // Migration pour bases existantes
      try { sqliteDB.prepare('ALTER TABLE credit_transactions ADD COLUMN reference TEXT').run(); } catch {}
      db = sqliteDB;
      console.log('[db] Base de données prête:', DB_PATH);
    } catch (e) {
      console.error('[db] Erreur initialisation:', e.message);
    }
  } else {
    console.error('[db] sql.js non disponible — lancez: npm install');
  }

  // Attendre que le port soit libre (jusqu'à 15s)
  const net = require('net');
  const isPortFree = (p) => new Promise(resolve => {
    const tester = net.createServer();
    tester.once('error', () => resolve(false));
    tester.once('listening', () => { tester.close(); resolve(true); });
    tester.listen(p, '0.0.0.0');
  });

  for (let i = 0; i < 5; i++) {
    const free = await isPortFree(PORT);
    if (free) break;
    console.log(`[server] Port ${PORT} occupé, tentative ${i + 1}/5...`);
    try { execSync(`fuser -k ${PORT}/tcp`, { stdio: 'ignore' }); } catch {}
    await new Promise(r => setTimeout(r, 2000));
  }

  const server = app.listen(PORT, HOST, () => {
    console.log(`[server] BotHoster démarré sur ${HOST}:${PORT}`);
    console.log(`[server] VPS IP: ${VPS_IP}`);
    if (!db) console.warn('[server] ATTENTION: base de données non disponible');
  });

  server.on('error', async (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`[server] Port ${PORT} occupé, dernière tentative...`);
      try { execSync(`fuser -k ${PORT}/tcp`, { stdio: 'ignore' }); } catch {}
      await new Promise(r => setTimeout(r, 3000));
      server.listen(PORT, HOST);
    } else {
      console.error('[server] Erreur critique:', err.message);
      process.exit(1);
    }
  });
})();
