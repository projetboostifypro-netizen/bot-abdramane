const http = require('http');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const PORT = Number(process.env.PORT || 3001);
const HOST = process.env.HOST || '0.0.0.0';
const BOTS_DIR = process.env.BOTS_DIR || path.join(process.cwd(), 'bots');
const API_URL = process.env.BOTHOSTER_API_URL || 'https://ynjtcdswwazceswzztkn.supabase.co';
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
// Clé anon Supabase (publique) — pour authentifier les téléchargements Storage
const ANON_KEY = process.env.SUPABASE_ANON_KEY || '__SUPABASE_ANON_KEY__';
const SYNC_INTERVAL_MS = 5000;

// ─── Proxy mode (alternative to service_role key) ────────────────────────────
// If BOT_PROXY_URL and BOT_PROXY_SECRET are set, all Supabase calls go through
// the Edge Function proxy instead of direct Supabase REST API.
// BOT_PROXY_URL = https://ynjtcdswwazceswzztkn.supabase.co/functions/v1/bot-proxy
// BOT_PROXY_SECRET = the secret configured in Lovable / Supabase
const PROXY_URL = process.env.BOT_PROXY_URL || 'https://ynjtcdswwazceswzztkn.supabase.co/functions/v1/bot-proxy';
const PROXY_SECRET = process.env.BOT_PROXY_SECRET || process.env.SECRET_DU_SERVEUR_DE_BOT || '78d00720ac518defd02895977380e53beafddcd16088009038e419a4d77948c8';

const ENTRY_CANDIDATES = {
  nodejs: ['index.js', 'main.js', 'app.js'],
  python: ['main.py', 'bot.py', 'index.py'],
};

const activeBots = new Map();
// Track crash-restart counts per bot: botId → { count, windowStart }
const restartCounts = new Map();
const MAX_AUTO_RESTARTS = 5;
const RESTART_WINDOW_MS = 10 * 60 * 1000; // 10 min window
const RESTART_DELAY_BASE_MS = 5000;       // 5s, 10s, 15s... up to 30s

// ─── Migration: move bots from old server/bots path to new bots path ─────────
(function migrateBotDir() {
  const candidates = [
    path.join(__dirname, 'server', 'bots'),
    path.join(__dirname, '..', 'server', 'bots'),
  ];
  for (const oldDir of candidates) {
    try {
      if (!fs.existsSync(BOTS_DIR) && fs.existsSync(oldDir)) {
        fs.renameSync(oldDir, BOTS_DIR);
        console.log(`[init] Migrated bots directory: ${oldDir} → ${BOTS_DIR}`);
        break;
      }
    } catch (e) {
      console.warn(`[init] Could not migrate bots dir from ${oldDir}:`, e.message);
    }
  }
})();

fs.mkdirSync(BOTS_DIR, { recursive: true });

// ─── .env file parser (for file manager edits) ───────────────────────────────
function parseEnvFile(content) {
  const vars = {};
  for (const line of content.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx === -1) continue;
    const key = trimmed.substring(0, eqIdx).trim();
    let val = trimmed.substring(eqIdx + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) ||
        (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (key) vars[key] = val;
  }
  return vars;
}

// Strip ANSI escape codes from bot output so logs are readable
function stripAnsi(str) {
  return str.replace(/\x1B\[[0-9;]*[mGKHFJA-Z]/g, '');
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function sendJson(res, statusCode, payload) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.end(JSON.stringify(payload));
}

function normalizeBotId(botId) {
  return String(botId || '').trim().replace(/[^a-zA-Z0-9_-]/g, '');
}

function getBotDirectory(botId) {
  const safeBotId = normalizeBotId(botId);
  if (!safeBotId) return null;
  return path.join(BOTS_DIR, safeBotId);
}

function resolveRuntime(language) {
  return language === 'python'
    ? { command: 'python3', key: 'python' }
    : { command: 'node', key: 'nodejs' };
}

function resolveActualBotDir(botDir) {
  // If the ZIP extracted into a single subdirectory (common), use that instead
  try {
    const entries = fs.readdirSync(botDir);
    const files = entries.filter(e => fs.statSync(path.join(botDir, e)).isFile());
    const dirs = entries.filter(e => fs.statSync(path.join(botDir, e)).isDirectory());
    if (files.length === 0 && dirs.length === 1) {
      const sub = path.join(botDir, dirs[0]);
      console.log(`[deploy] ZIP extracted to subdirectory: ${dirs[0]}, using it as root`);
      return sub;
    }
  } catch {}
  return botDir;
}

function resolveEntryFile(botDir, config = {}) {
  const runtime = resolveRuntime(config.language);
  const customEntries = [config.entry, config.entrypoint, config.start_file]
    .filter(Boolean)
    .map((entry) => path.basename(String(entry)));

  const candidates = [...customEntries, ...ENTRY_CANDIDATES[runtime.key]];

  // Try in the direct botDir first, then in subdirectories (one level)
  const searchDirs = [botDir];
  try {
    fs.readdirSync(botDir)
      .filter(e => fs.statSync(path.join(botDir, e)).isDirectory())
      .forEach(d => searchDirs.push(path.join(botDir, d)));
  } catch {}

  for (const dir of searchDirs) {
    for (const candidate of candidates) {
      const fullPath = path.join(dir, candidate);
      if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
        console.log(`[deploy] Entry file found: ${fullPath}`);
        return fullPath; // return full path so cwd can be set correctly
      }
    }
  }
  return null;
}

function buildProcessEnv(envVars, workDir = null) {
  const env = { ...process.env };
  // Load .env file from disk first (file manager edits land here)
  if (workDir) {
    const dotenvPath = path.join(workDir, '.env');
    if (fs.existsSync(dotenvPath)) {
      try {
        const fileVars = parseEnvFile(fs.readFileSync(dotenvPath, 'utf8'));
        Object.assign(env, fileVars);
        console.log(`[env] Loaded ${Object.keys(fileVars).length} var(s) from .env`);
      } catch (e) {
        console.warn('[env] Could not read .env file:', e.message);
      }
    }
  }
  // DB env_vars override .env file (explicit settings take priority)
  if (!envVars || typeof envVars !== 'object' || Array.isArray(envVars)) return env;
  for (const [key, value] of Object.entries(envVars)) {
    if (!key) continue;
    env[String(key)] = value == null ? '' : String(value);
  }
  return env;
}

function getUptimeSeconds(startedAt) {
  return Math.max(0, Math.floor((Date.now() - startedAt) / 1000));
}

// ─── Supabase helpers ─────────────────────────────────────────────────────────
// Supports two modes:
//  1. Direct mode: uses SUPABASE_SERVICE_ROLE_KEY directly
//  2. Proxy mode:  calls an Edge Function (BOT_PROXY_URL) with BOT_PROXY_SECRET

const USE_PROXY = !!(PROXY_URL && PROXY_SECRET);

function supabaseHeaders() {
  return {
    'Content-Type': 'application/json',
    apikey: SERVICE_KEY,
    Authorization: `Bearer ${SERVICE_KEY}`,
  };
}

function proxyHeaders() {
  return {
    'Content-Type': 'application/json',
    'x-bot-secret': PROXY_SECRET,
  };
}

async function supabaseGet(path) {
  if (USE_PROXY) {
    const res = await fetch(PROXY_URL, {
      method: 'POST',
      headers: proxyHeaders(),
      body: JSON.stringify({ method: 'GET', path, body: null }),
    });
    if (!res.ok) {
      const text = await res.text();
      console.error(`[PROXY] GET ${path} → HTTP ${res.status}: ${text}`);
      return [];
    }
    return res.json();
  }
  const res = await fetch(`${API_URL}/rest/v1${path}`, { headers: supabaseHeaders() });
  return res.json();
}

async function supabasePatch(path, body) {
  if (USE_PROXY) {
    const res = await fetch(PROXY_URL, {
      method: 'POST',
      headers: proxyHeaders(),
      body: JSON.stringify({ method: 'PATCH', path, body }),
    });
    if (!res.ok) {
      const text = await res.text();
      console.error(`[PROXY] PATCH ${path} → HTTP ${res.status}: ${text}`);
    }
    return;
  }
  const res = await fetch(`${API_URL}/rest/v1${path}`, {
    method: 'PATCH',
    headers: { ...supabaseHeaders(), Prefer: 'return=representation' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text();
    console.error(`[SUPABASE] PATCH ${path} → HTTP ${res.status}: ${text}`);
  }
}

async function supabasePost(path, body) {
  if (USE_PROXY) {
    const res = await fetch(PROXY_URL, {
      method: 'POST',
      headers: proxyHeaders(),
      body: JSON.stringify({ method: 'POST', path, body }),
    });
    if (!res.ok) {
      const text = await res.text();
      console.error(`[PROXY] POST ${path} → HTTP ${res.status}: ${text}`);
    }
    return;
  }
  const res = await fetch(`${API_URL}/rest/v1${path}`, {
    method: 'POST',
    headers: { ...supabaseHeaders(), Prefer: 'return=minimal' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text();
    console.error(`[SUPABASE] POST ${path} → HTTP ${res.status}: ${text}`);
  }
}

async function pushLog(botId, userId, level, message) {
  if ((!SERVICE_KEY && !USE_PROXY) || !userId || !message) return;
  try {
    await supabasePost('/bot_logs', {
      bot_id: botId,
      user_id: userId,
      level,
      message: String(message).slice(0, 1000),
    });
  } catch (error) {
    console.error('Failed to push log:', error.message);
  }
}

async function updateStatus(botId, status, extra = {}) {
  if ((!SERVICE_KEY && !USE_PROXY) || !botId) return;
  try {
    await supabasePatch(`/bots?id=eq.${encodeURIComponent(botId)}`, {
      status,
      updated_at: new Date().toISOString(),
      ...extra,
    });
  } catch (error) {
    console.error('Failed to update status:', error.message);
  }
}

// ─── File download & extract ──────────────────────────────────────────────────

async function downloadFile(url, destPath) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Download failed: ${res.status} ${res.statusText}`);
  const buffer = Buffer.from(await res.arrayBuffer());
  fs.writeFileSync(destPath, buffer);
}

async function downloadFromStorage(sourceUrl, destPath) {
  console.log(`[storage] source_url = ${sourceUrl}`);

  // If source_url is already a full HTTP URL (public bucket), download directly
  if (sourceUrl.startsWith('http')) {
    console.log(`[storage] Downloading directly from full URL`);
    const res = await fetch(sourceUrl);
    if (!res.ok) throw new Error(`Storage download failed: ${res.status}`);
    const buffer = Buffer.from(await res.arrayBuffer());
    fs.writeFileSync(destPath, buffer);
    return;
  }

  // Parse bucket and path — supports both:
  //   "bucket::userId/timestamp_file.zip"  (new format with explicit bucket)
  //   "userId/timestamp_file.zip"          (legacy format, defaults to bot-files)
  let bucketId, storagePath;
  if (sourceUrl.includes('::')) {
    const sep = sourceUrl.indexOf('::');
    bucketId = sourceUrl.substring(0, sep);
    storagePath = sourceUrl.substring(sep + 2);
  } else {
    bucketId = 'bot-files';
    storagePath = sourceUrl;
  }
  // URL-encode bucket name so spaces don't break the HTTP path
  const encodedBucket = encodeURIComponent(bucketId);
  console.log(`[storage] bucket=${bucketId}, path=${storagePath}`);

  if (USE_PROXY) {
    // Ask the Edge Function to create a signed URL for the file
    const signPath = `/storage/v1/object/sign/${encodedBucket}/${storagePath}`;
    console.log(`[storage] Requesting signed URL for: ${signPath}`);
    const res = await fetch(PROXY_URL, {
      method: 'POST',
      headers: proxyHeaders(),
      body: JSON.stringify({ method: 'POST', path: signPath, body: { expiresIn: 120 } }),
    });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Storage sign failed: ${res.status} ${text}`);
    }
    const data = await res.json();
    console.log(`[storage] Sign response:`, JSON.stringify(data));
    const signedUrl = data.signedURL || data.signedUrl;
    if (!signedUrl) throw new Error(`No signed URL in response: ${JSON.stringify(data)}`);
    const downloadUrl = signedUrl.startsWith('http') ? signedUrl : `${API_URL}/storage/v1${signedUrl}`;
    console.log(`[storage] Downloading from: ${downloadUrl.substring(0, 120)}...`);
    const dlRes = await fetch(downloadUrl, {
      headers: { 'apikey': ANON_KEY }
    });
    if (!dlRes.ok) {
      const errBody = await dlRes.text();
      throw new Error(`Storage download failed: ${dlRes.status} ${errBody.substring(0, 200)}`);
    }
    const buffer = Buffer.from(await dlRes.arrayBuffer());
    console.log(`[storage] Downloaded ${buffer.length} bytes`);
    fs.writeFileSync(destPath, buffer);
    return;
  }

  const url = `${API_URL}/storage/v1/object/${encodedBucket}/${storagePath}`;
  const res = await fetch(url, { headers: supabaseHeaders() });
  if (!res.ok) throw new Error(`Storage download failed: ${res.status}`);
  const buffer = Buffer.from(await res.arrayBuffer());
  fs.writeFileSync(destPath, buffer);
}

function extractArchive(archivePath, destDir) {
  fs.mkdirSync(destDir, { recursive: true });
  const ext = archivePath.toLowerCase();

  if (ext.endsWith('.zip')) {
    try {
      execSync(`unzip -o "${archivePath}" -d "${destDir}"`, { stdio: 'inherit' });
    } catch {
      // Try with node-based fallback if unzip not available
      throw new Error('unzip not available. Please install unzip on the server.');
    }
  } else if (ext.endsWith('.tar.gz') || ext.endsWith('.tgz')) {
    execSync(`tar -xzf "${archivePath}" -C "${destDir}"`, { stdio: 'inherit' });
  } else {
    // Single file — just copy it
    const filename = path.basename(archivePath);
    fs.copyFileSync(archivePath, path.join(destDir, filename));
  }
}

async function deployBotFiles(botRecord) {
  const botId = normalizeBotId(botRecord.id);
  const botDir = getBotDirectory(botId);

  if (!botDir) throw new Error('Invalid bot ID');

  // Check if valid bot files already exist (not just leftover _tmp_ files)
  if (fs.existsSync(botDir)) {
    try {
      const items = fs.readdirSync(botDir);
      const validFiles = items.filter(f => !f.startsWith('_tmp_'));
      if (validFiles.length > 0) {
        console.log(`[deploy] Bot dir already has files, skipping download: [${validFiles.join(', ')}]`);
        return botDir;
      }
      // Clean up stale _tmp_ files and empty dirs before re-downloading
      if (items.length > 0) {
        console.log(`[deploy] Cleaning stale files in bot dir: [${items.join(', ')}]`);
        for (const item of items) {
          const full = path.join(botDir, item);
          try {
            const stat = fs.statSync(full);
            if (stat.isDirectory()) fs.rmSync(full, { recursive: true });
            else fs.unlinkSync(full);
          } catch {}
        }
      }
    } catch {}
  }

  fs.mkdirSync(botDir, { recursive: true });

  // .zip extension required so extractArchive recognises the format
  const tmpFile = path.join(BOTS_DIR, `_tmp_${botId}.zip`);

  try {
    if (botRecord.source_type === 'url' && botRecord.source_url) {
      await downloadFile(botRecord.source_url, tmpFile);
      extractArchive(tmpFile, botDir);
    } else if (botRecord.source_type === 'upload' && botRecord.source_url) {
      await downloadFromStorage(botRecord.source_url, tmpFile);
      extractArchive(tmpFile, botDir);
    } else {
      throw new Error('No valid source configured for this bot.');
    }
  } finally {
    if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile);
  }

  // Log extracted files to help debug
  try {
    const listDir = (dir, prefix = '') => {
      const entries = fs.readdirSync(dir);
      entries.forEach(e => {
        const full = path.join(dir, e);
        if (fs.statSync(full).isDirectory()) {
          console.log(`[deploy] ${prefix}${e}/`);
          listDir(full, prefix + '  ');
        } else {
          console.log(`[deploy] ${prefix}${e}`);
        }
      });
    };
    console.log(`[deploy] Extracted files in ${botDir}:`);
    listDir(botDir);
  } catch {}

  return botDir;
}

// ─── File manager helpers ─────────────────────────────────────────────────────

const TEXT_EXTS = new Set([
  '.js', '.mjs', '.cjs', '.ts', '.py', '.json', '.env',
  '.txt', '.yml', '.yaml', '.md', '.sh', '.toml', '.cfg',
  '.ini', '.xml', '.html', '.css', '.jsx', '.tsx', '.rb',
]);
const EXCLUDE_DIRS = new Set(['node_modules', '.git', '__pycache__', '.venv', 'venv', 'dist', 'build']);
const MAX_FILE_SIZE = 500 * 1024; // 500 KB

function scanTextFiles(dir, prefix = '') {
  const results = [];
  try {
    for (const entry of fs.readdirSync(dir)) {
      if (EXCLUDE_DIRS.has(entry)) continue;
      const full = path.join(dir, entry);
      const rel = prefix ? `${prefix}/${entry}` : entry;
      try {
        const stat = fs.statSync(full);
        if (stat.isDirectory()) {
          results.push(...scanTextFiles(full, rel));
        } else if (stat.size < MAX_FILE_SIZE) {
          const ext = path.extname(entry).toLowerCase();
          const base = entry.toLowerCase();
          if (TEXT_EXTS.has(ext) || base.startsWith('.env') || base === '.env') {
            results.push({ rel, full });
          }
        }
      } catch {}
    }
  } catch {}
  return results;
}

async function scanAndStoreBotFiles(botId, botDir) {
  try {
    const files = scanTextFiles(botDir);
    if (!files.length) return;

    // Get existing records so we don't overwrite user-modified files
    const existing = await supabaseGet(`/bot_files?bot_id=eq.${botId}&select=path,is_modified`);
    const existingMap = new Map((existing || []).map(f => [f.path, f.is_modified]));

    for (const { rel, full } of files) {
      try {
        const content = fs.readFileSync(full, 'utf8');
        const isModified = existingMap.get(rel);
        if (isModified === undefined) {
          // New file → insert
          await supabasePost('/bot_files', { bot_id: botId, path: rel, content, is_modified: false });
        } else if (!isModified) {
          // Existing unmodified → update (VPS is source of truth)
          await supabasePatch(
            `/bot_files?bot_id=eq.${botId}&path=eq.${encodeURIComponent(rel)}`,
            { content, updated_at: new Date().toISOString() }
          );
        }
        // is_modified=true → skip (user has pending edits)
      } catch (e) {
        console.warn(`[files] scan error for ${rel}: ${e.message}`);
      }
    }
    console.log(`[files] Scanned ${files.length} text file(s) for bot ${botId}`);
  } catch (e) {
    console.warn(`[files] scanAndStoreBotFiles failed: ${e.message}`);
  }
}

async function applyModifiedFiles(botId, botDir) {
  try {
    const modified = await supabaseGet(`/bot_files?bot_id=eq.${botId}&is_modified=eq.true`);
    if (!modified || !modified.length) return;

    console.log(`[files] Applying ${modified.length} modified file(s) for bot ${botId}`);
    for (const file of modified) {
      try {
        const fullPath = path.join(botDir, file.path);
        fs.mkdirSync(path.dirname(fullPath), { recursive: true });
        fs.writeFileSync(fullPath, file.content, 'utf8');
        console.log(`[files] Applied: ${file.path}`);
      } catch (e) {
        console.warn(`[files] Could not apply ${file.path}: ${e.message}`);
      }
    }
    // Mark all as applied
    await supabasePatch(`/bot_files?bot_id=eq.${botId}&is_modified=eq.true`, {
      is_modified: false,
      updated_at: new Date().toISOString(),
    });
    void pushLog(botId, null, 'info', `${modified.length} fichier(s) modifié(s) appliqué(s) avec succès.`);
  } catch (e) {
    console.warn(`[files] applyModifiedFiles failed: ${e.message}`);
  }
}

// ─── Bot lifecycle ────────────────────────────────────────────────────────────

function startBot(botId, config = {}) {
  const safeBotId = normalizeBotId(botId);
  if (!safeBotId) return { success: false, message: 'Invalid bot id' };
  if (activeBots.has(safeBotId)) return { success: false, message: 'Bot already running' };

  const botDir = getBotDirectory(safeBotId);
  if (!botDir || !fs.existsSync(botDir)) {
    return { success: false, message: 'Bot files not found' };
  }

  // Log bot directory contents
  try {
    const items = fs.readdirSync(botDir);
    console.log(`[deploy] Bot dir ${botDir}: [${items.join(', ')}]`);
    items.forEach(item => {
      const full = path.join(botDir, item);
      if (fs.statSync(full).isDirectory()) {
        console.log(`[deploy]   ${item}/: [${fs.readdirSync(full).join(', ')}]`);
      }
    });
  } catch {}

  const runtime = resolveRuntime(config.language);
  const entryFileFull = resolveEntryFile(botDir, config);

  if (!entryFileFull) {
    return {
      success: false,
      message: runtime.key === 'python'
        ? 'No Python entry file found (main.py, bot.py, index.py)'
        : 'No Node entry file found (index.js, main.js, app.js)',
    };
  }

  // Working directory is the folder containing the entry file
  const workDir = path.dirname(entryFileFull);
  const entryFile = path.basename(entryFileFull);

  // Run npm install if package.json exists and node_modules doesn't
  if (runtime.key === 'nodejs') {
    const pkgJson = path.join(workDir, 'package.json');
    const nodeModules = path.join(workDir, 'node_modules');
    if (fs.existsSync(pkgJson) && !fs.existsSync(nodeModules)) {
      console.log(`[deploy] Running npm install in ${workDir}...`);
      void pushLog(safeBotId, config.user_id, 'info', 'Installation des dépendances (npm install)...');
      try {
        execSync('npm install --production --no-fund --no-audit', { cwd: workDir, stdio: 'inherit', timeout: 120000 });
        console.log(`[deploy] npm install done`);
        void pushLog(safeBotId, config.user_id, 'info', 'Dépendances installées avec succès.');
      } catch (e) {
        console.error(`[deploy] npm install failed: ${e.message}`);
        void pushLog(safeBotId, config.user_id, 'error', `npm install échoué: ${e.message}`);
      }
    }
  }

  // ── CommonJS/ESM compatibility fix ──────────────────────────────────────────
  // If the entry file uses require() but package.json declares "type":"module",
  // Node.js will refuse to run it. We patch package.json to remove that field.
  if (runtime.key === 'nodejs') {
    const pkgPath = path.join(workDir, 'package.json');
    if (fs.existsSync(pkgPath)) {
      try {
        const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
        if (pkg.type === 'module') {
          const entrySource = fs.existsSync(path.join(workDir, entryFile))
            ? fs.readFileSync(path.join(workDir, entryFile), 'utf8')
            : '';
          // If the file contains require() calls, it's CommonJS — remove "type":"module"
          if (entrySource.includes('require(')) {
            delete pkg.type;
            fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2));
            console.log(`[deploy] Patched package.json: removed "type":"module" (CommonJS bot detected)`);
            void pushLog(safeBotId, config.user_id, 'info', 'Compatibilité CommonJS/ESM corrigée automatiquement.');
          }
        }
      } catch (e) {
        console.warn(`[deploy] Could not patch package.json: ${e.message}`);
      }
    }
  }

  const child = spawn(runtime.command, [entryFile], {
    cwd: workDir,
    env: buildProcessEnv(config.env_vars, workDir),
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  const startedAt = Date.now();

  child.stdout.on('data', (data) => {
    const raw = data.toString().trim();
    if (!raw) return;
    // Keep data-URLs intact (QR codes), strip ANSI from everything else
    const message = raw.startsWith('data:') ? raw : stripAnsi(raw);
    if (message) void pushLog(safeBotId, config.user_id, 'info', message);
  });

  child.stderr.on('data', (data) => {
    const raw = data.toString().trim();
    if (!raw) return;
    const message = raw.startsWith('data:') ? raw : stripAnsi(raw);
    if (message) void pushLog(safeBotId, config.user_id, 'error', message);
  });

  child.on('error', (error) => {
    void pushLog(safeBotId, config.user_id, 'error', `Process error: ${error.message}`);
  });

  child.on('exit', (code, signal) => {
    activeBots.delete(safeBotId);
    const uptime_seconds = getUptimeSeconds(startedAt);

    // Manually stopped (SIGTERM/SIGKILL) or clean exit → no restart
    const wasManualStop = signal === 'SIGTERM' || signal === 'SIGKILL' || code === 0;
    if (wasManualStop) {
      void updateStatus(safeBotId, code === 0 ? 'stopped' : 'stopped', { uptime_seconds });
      restartCounts.delete(safeBotId);
      return;
    }

    // Crashed — no auto-restart. User must restart manually from the dashboard.
    void pushLog(safeBotId, config.user_id, 'warn',
      `Bot arrêté inopinément (code ${code ?? signal}). Redémarrez-le manuellement depuis le tableau de bord.`);
    void updateStatus(safeBotId, 'error', { uptime_seconds });
    restartCounts.delete(safeBotId);
  });

  activeBots.set(safeBotId, { process: child, startedAt, entryFile, userId: config.user_id, config });

  void pushLog(safeBotId, config.user_id, 'info', `Bot started with ${entryFile}`);
  void updateStatus(safeBotId, 'online', {
    last_started_at: new Date(startedAt).toISOString(),
    uptime_seconds: 0,
  });

  return { success: true, message: `Bot started with ${entryFile}` };
}

function stopBot(botId) {
  const safeBotId = normalizeBotId(botId);
  const bot = activeBots.get(safeBotId);
  if (!bot) return { success: false, message: 'Bot not found' };

  bot.process.kill('SIGTERM');
  setTimeout(() => {
    if (!activeBots.has(safeBotId)) return;
    bot.process.kill('SIGKILL');
    activeBots.delete(safeBotId);
    void updateStatus(safeBotId, 'stopped', { uptime_seconds: getUptimeSeconds(bot.startedAt) });
  }, 5000).unref();

  return { success: true, message: 'Stop signal sent' };
}

// ─── DB sync loop ─────────────────────────────────────────────────────────────
// The server watches Supabase for bot status changes instead of waiting for HTTP calls.
// This avoids needing a public HTTP port.

let syncing = false;

async function syncBots() {
  if ((!SERVICE_KEY && !USE_PROXY) || syncing) return;
  syncing = true;

  try {
    // 1. Find bots with status "deploying" that this server should start
    const deployingBots = await supabaseGet('/bots?status=eq.deploying&select=*');

    for (const bot of Array.isArray(deployingBots) ? deployingBots : []) {
      const safeBotId = normalizeBotId(bot.id);
      if (activeBots.has(safeBotId)) continue; // Already running

      // ── RAM limit check ──────────────────────────────────────────────────────
      try {
        const [subRows, onlineRows] = await Promise.all([
          supabaseGet(`/subscriptions?user_id=eq.${bot.user_id}&select=ram_limit`),
          supabaseGet(`/bots?user_id=eq.${bot.user_id}&status=eq.online&select=ram_usage`),
        ]);
        const ramLimit = (Array.isArray(subRows) && subRows[0]?.ram_limit) || 308;
        const totalRam = (Array.isArray(onlineRows) ? onlineRows : [])
          .reduce((sum, b) => sum + (b.ram_usage || 0), 0);

        if (totalRam >= ramLimit) {
          console.log(`[sync] RAM limit reached for user ${bot.user_id}: ${Math.round(totalRam)}/${ramLimit} MB`);
          await updateStatus(safeBotId, 'error');
          await pushLog(safeBotId, bot.user_id, 'error',
            `Limite RAM atteinte — ${Math.round(totalRam)} MB utilisés sur ${ramLimit} MB. Arrêtez un bot en cours pour libérer de la RAM.`);
          continue;
        }
      } catch (ramErr) {
        console.warn(`[sync] RAM check failed for bot ${safeBotId}:`, ramErr.message);
      }
      // ─────────────────────────────────────────────────────────────────────────

      console.log(`[sync] Starting bot ${safeBotId}...`);
      void pushLog(safeBotId, bot.user_id, 'info', 'Téléchargement des fichiers du bot...');

      try {
        const botDir = await deployBotFiles(bot);
        // Apply pending file edits before starting
        await applyModifiedFiles(safeBotId, botDir);
        // Scan/update file index in background (always, even on restart)
        void scanAndStoreBotFiles(safeBotId, botDir).catch(e => console.warn('[files] scan:', e.message));
        const result = startBot(safeBotId, {
          language: bot.language,
          env_vars: bot.env_vars,
          user_id: bot.user_id,
        });

        if (!result.success) {
          await updateStatus(safeBotId, 'error');
          await pushLog(safeBotId, bot.user_id, 'error', result.message);
        }
      } catch (err) {
        console.error(`[sync] Failed to deploy bot ${safeBotId}:`, err.message);
        await updateStatus(safeBotId, 'error');
        await pushLog(safeBotId, bot.user_id, 'error', `Erreur de déploiement: ${err.message}`);
      }
    }

    // 2. Stop bots that are marked "stopped" or "offline" but still running locally
    for (const [safeBotId, botData] of activeBots.entries()) {
      try {
        const rows = await supabaseGet(`/bots?id=eq.${safeBotId}&select=status`);
        const row = Array.isArray(rows) ? rows[0] : null;
        if (row && (row.status === 'stopped' || row.status === 'offline')) {
          console.log(`[sync] Stopping bot ${safeBotId} (status=${row.status})`);
          stopBot(safeBotId);
        }
      } catch (err) {
        console.error(`[sync] Error checking bot ${safeBotId}:`, err.message);
      }
    }
  } catch (err) {
    console.error('[sync] Sync error:', err.message);
  } finally {
    syncing = false;
  }
}

// ─── Metrics loop ─────────────────────────────────────────────────────────────
// Every 30s: collect CPU% and RAM (MB) for each active bot process and push to DB.

function getBotMetrics(pid) {
  try {
    // ps -o %cpu,rss returns: CPU% and RSS in KB, one line per PID
    const out = execSync(`ps -o %cpu,rss -p ${pid} --no-headers 2>/dev/null`, { timeout: 5000 })
      .toString().trim().split(/\s+/);
    if (out.length < 2) return null;
    const cpu = parseFloat(out[0]);
    const ramMb = parseInt(out[1], 10) / 1024;
    return { cpu: isNaN(cpu) ? 0 : cpu, ram: isNaN(ramMb) ? 0 : ramMb };
  } catch {
    return null;
  }
}

async function updateMetrics() {
  // Step 1: collect live RAM per bot and push to DB
  const userRamMap = {}; // userId → [{botId, ram, startedAt}]

  for (const [safeBotId, botData] of activeBots.entries()) {
    const pid = botData.process?.pid;
    if (!pid) continue;
    const metrics = getBotMetrics(pid);
    if (!metrics) continue;

    try {
      await supabasePatch(
        `/bots?id=eq.${safeBotId}`,
        {
          cpu_usage: Math.round(metrics.cpu * 10) / 10,
          ram_usage: Math.round(metrics.ram * 10) / 10,
          uptime_seconds: getUptimeSeconds(botData.startedAt),
        }
      );
    } catch (err) {
      console.error(`[metrics] Failed to update metrics for ${safeBotId}:`, err.message);
    }

    if (botData.userId) {
      if (!userRamMap[botData.userId]) userRamMap[botData.userId] = [];
      userRamMap[botData.userId].push({ botId: safeBotId, ram: metrics.ram, startedAt: botData.startedAt });
    }
  }

  // Step 2: enforce RAM limits — stop bots of users who exceed their subscription
  for (const [userId, bots] of Object.entries(userRamMap)) {
    try {
      const subRows = await supabaseGet(`/subscriptions?user_id=eq.${userId}&select=ram_limit`);
      const ramLimit = (Array.isArray(subRows) && subRows[0]?.ram_limit) || 308;
      let totalRam = bots.reduce((sum, b) => sum + b.ram, 0);

      if (totalRam > ramLimit) {
        console.log(`[metrics] User ${userId} over RAM limit: ${Math.round(totalRam)}/${ramLimit} MB — stopping excess bots`);
        // Stop heaviest bots first until we are back within the limit
        const sorted = [...bots].sort((a, b) => b.ram - a.ram);
        for (const bot of sorted) {
          if (totalRam <= ramLimit) break;
          console.log(`[metrics] Force-stopping ${bot.botId} (${Math.round(bot.ram)} MB)`);
          await pushLog(bot.botId, userId, 'error',
            `Bot arrêté automatiquement — limite RAM dépassée (${Math.round(totalRam)} MB utilisés / ${ramLimit} MB max). Arrêtez d'autres bots ou passez à un plan supérieur.`);
          stopBot(bot.botId);
          totalRam -= bot.ram;
        }
      }
    } catch (err) {
      console.warn(`[metrics] RAM enforcement failed for user ${userId}:`, err.message);
    }
  }
}

// ─── HTTP server (status only — no longer needed for control) ─────────────────

function getStatusPayload() {
  const bots = Array.from(activeBots.entries()).map(([id, bot]) => ({
    id,
    entryFile: bot.entryFile,
    uptime: getUptimeSeconds(bot.startedAt),
  }));
  return { active_bots: bots.length, bots };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => { body += chunk; });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

async function parseJsonBody(req) {
  const rawBody = await readBody(req);
  if (!rawBody) return {};
  try { return JSON.parse(rawBody); } catch { throw new Error('Invalid JSON body'); }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);

  if (req.method === 'OPTIONS') return sendJson(res, 204, {});

  try {
    if (req.method === 'GET' && url.pathname === '/') {
      return sendJson(res, 200, {
        status: 'ok',
        service: 'BotHoster',
        active: activeBots.size,
        uptime: Math.floor(process.uptime()),
        mode: 'db-sync',
      });
    }

    if (req.method === 'GET' && url.pathname === '/status') {
      return sendJson(res, 200, getStatusPayload());
    }

    // Keep HTTP endpoints for manual use / debugging
    if (req.method === 'POST' && url.pathname === '/start') {
      const { botId, config } = await parseJsonBody(req);
      if (!botId) return sendJson(res, 400, { success: false, message: 'botId is required' });
      const result = startBot(botId, config || {});
      return sendJson(res, result.success ? 200 : 400, result);
    }

    if (req.method === 'POST' && url.pathname === '/stop') {
      const { botId } = await parseJsonBody(req);
      if (!botId) return sendJson(res, 400, { success: false, message: 'botId is required' });
      const result = stopBot(botId);
      return sendJson(res, result.success ? 200 : 404, result);
    }

    return sendJson(res, 404, { error: 'Not found' });
  } catch (error) {
    return sendJson(res, 400, { success: false, message: error.message || 'Request failed' });
  }
});

// ─── Shutdown ─────────────────────────────────────────────────────────────────

function shutdown(signal) {
  console.log(`Received ${signal}, shutting down cleanly...`);
  for (const [botId, bot] of activeBots.entries()) {
    bot.process.kill('SIGTERM');
    activeBots.delete(botId);
  }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// ─── Start ────────────────────────────────────────────────────────────────────

server.listen(PORT, HOST, () => {
  console.log(`BotHoster running on http://${HOST}:${PORT}`);
  if (USE_PROXY) {
    console.log(`Mode: Edge Function proxy → ${PROXY_URL}`);
  } else if (SERVICE_KEY) {
    console.log(`Mode: Direct Supabase (service_role key)`);
  } else {
    console.log(`⚠ AVERTISSEMENT: Aucune clé Supabase configurée. Les bots ne pourront pas être gérés.`);
    console.log(`  → Configurez BOT_PROXY_URL + BOT_PROXY_SECRET  (mode proxy Edge Function)`);
    console.log(`  → Ou configurez SUPABASE_SERVICE_ROLE_KEY      (mode direct Supabase)`);
  }
  console.log(`DB-sync mode: checking Supabase every ${SYNC_INTERVAL_MS / 1000}s`);

  // Test proxy/supabase connection at startup
  if (USE_PROXY) {
    fetch(PROXY_URL, {
      method: 'POST',
      headers: proxyHeaders(),
      body: JSON.stringify({ method: 'GET', path: '/bots?limit=1', body: null }),
    }).then(async (res) => {
      if (res.ok) {
        console.log('[PROXY] ✅ Connexion Edge Function OK');
      } else {
        const text = await res.text();
        console.error(`[PROXY] ❌ Erreur Edge Function HTTP ${res.status}: ${text}`);
      }
    }).catch((err) => {
      console.error(`[PROXY] ❌ Impossible de joindre l'Edge Function: ${err.message}`);
    });
  } else if (SERVICE_KEY) {
    fetch(`${API_URL}/rest/v1/bots?limit=1`, { headers: supabaseHeaders() })
      .then((res) => {
        if (res.ok) console.log('[SUPABASE] ✅ Connexion directe OK');
        else console.error(`[SUPABASE] ❌ Erreur HTTP ${res.status}`);
      }).catch((err) => console.error(`[SUPABASE] ❌ ${err.message}`));
  }

  // Initial sync then repeat
  void syncBots();
  setInterval(syncBots, SYNC_INTERVAL_MS);

  // Metrics loop: collect CPU/RAM every 30s
  setInterval(() => { void updateMetrics(); }, 30000);
});
