# BotHoster Server Pack

Archive prête à uploader avec `index.js` à la racine.

## Fichiers inclus

- `index.js`
- `package.json`

## Démarrage

1. Uploade le contenu de l'archive sur ton hébergeur.
2. Vérifie que `index.js` est bien à la racine.
3. Utilise la commande de démarrage : `node index.js`

## Variables d'environnement

- `PORT`
- `HOST`
- `SUPABASE_SERVICE_ROLE_KEY`
- `BOTHOSTER_API_URL`