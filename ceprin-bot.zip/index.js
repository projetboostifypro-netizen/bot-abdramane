import {
  useMultiFileAuthState, makeWASocket, DisconnectReason,
  fetchLatestBaileysVersion, makeCacheableSignalKeyStore,
} from "@whiskeysockets/baileys";
import qrcodeTerminal from "qrcode-terminal";
import pino from "pino";
import NodeCache from "node-cache";
import dotenv from "dotenv";
import fs from "fs";
import cron from "node-cron";
import fetch from "node-fetch";

dotenv.config();

// ━━━━━━━━━━━━━━━ CONFIG ━━━━━━━━━━━━━━━
export const config = {
  PREFIXE: process.env.PREFIXE || "!",
  AUTH_DIR: process.env.AUTH_DIR || "auth_baileys",
  NUMBER: process.env.BOT_NUMBER,
  USE_QR: process.env.USE_QR === "true",
  LOG_LEVEL: process.env.LOG_LEVEL || "info",
  RECONNECT_DELAY: parseInt(process.env.RECONNECT_DELAY) || 5000,
  BOT_NAME: process.env.BOT_NAME || "Ceprin",
  COMPANY_NAME: process.env.COMPANY_NAME || "Boostifypro",
  LICENSE_KEY: process.env.LICENSE_KEY || "",
  OPENAI_API_KEY: process.env.OPENAI_API_KEY || "",
  OPENAI_BASE_URL: (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, ""),
  OPENAI_MODEL: process.env.OPENAI_MODEL || "gpt-4o-mini",
};

const logger = pino({
  level: config.LOG_LEVEL,
  transport: { target: "pino-pretty", options: { colorize: true, ignore: "pid,hostname", translateTime: "HH:MM:ss", includeStack: true } },
  base: null,
  serializers: { error: pino.stdSerializers.error },
});
const msgRetryCounterCache = new NodeCache();
const processedMessages = new Set();
const conversationHistory = new Map();
let socket, intervalId, heartbeatInterval;

// Extract text from any message type
function extractMessageText(msg) {
  const m = msg.message;
  if (!m) return "";
  return m.conversation
    || m.extendedTextMessage?.text
    || m.ephemeralMessage?.message?.conversation
    || m.ephemeralMessage?.message?.extendedTextMessage?.text
    || m.viewOnceMessage?.message?.conversation
    || m.viewOnceMessage?.message?.extendedTextMessage?.text
    || m.imageMessage?.caption
    || m.videoMessage?.caption
    || m.documentMessage?.caption
    || "";
}

// ━━━━━━━━━━━━━━━ AI ━━━━━━━━━━━━━━━
async function callAI(messages) {
  if (!config.OPENAI_API_KEY) return null;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);
    const response = await fetch(`${config.OPENAI_BASE_URL}/chat/completions`, {
      method: "POST",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${config.OPENAI_API_KEY}` },
      body: JSON.stringify({ model: config.OPENAI_MODEL, messages, max_tokens: 500, temperature: 0.7 }),
    });
    clearTimeout(timeout);
    if (response.ok) {
      const data = await response.json();
      return data.choices?.[0]?.message?.content || null;
    }
    return null;
  } catch { return null; }
}

async function handleAIReply(sock, msg, from, text) {
  if (!config.OPENAI_API_KEY) return;
  const senderId = msg.key.participant || msg.key.remoteJid;
  const clientName = msg.pushName || "ami";
  if (!conversationHistory.has(senderId)) conversationHistory.set(senderId, []);
  const history = conversationHistory.get(senderId);
  const systemPrompt = `Tu es ${config.BOT_NAME}, un assistant WhatsApp intelligent créé par ${config.COMPANY_NAME}. Tu réponds en français de manière naturelle et utile. Utilise le formatage WhatsApp (*gras*, _italique_). Le client s'appelle ${clientName}.`;
  const msgs = [{ role: "system", content: systemPrompt }, ...history.slice(-10), { role: "user", content: text }];
  const reply = await callAI(msgs);
  if (reply) {
    history.push({ role: "user", content: text });
    history.push({ role: "assistant", content: reply });
    if (history.length > 20) history.splice(0, 2);
    await sock.sendMessage(from, { text: reply });
    logger.info(`🤖 IA → ${clientName}`);
  }
}

// ━━━━━━━━━━━━━━━ HEARTBEAT ━━━━━━━━━━━━━━━
function startHeartbeat(sock) {
  if (heartbeatInterval) clearInterval(heartbeatInterval);
  heartbeatInterval = setInterval(async () => {
    try { await sock.sendPresenceUpdate("available"); } catch {}
  }, 3 * 60 * 1000);
  logger.info("💓 Heartbeat démarré");
}

function cleanAuthFolder() {
  try { fs.rmSync(config.AUTH_DIR, { recursive: true, force: true }); logger.info("Dossier d'authentification nettoyé"); } catch {}
}

async function requestPairingCode(sock) {
  try {
    logger.info(`Demande de code de pairing pour ${config.NUMBER}`);
    const code = await sock.requestPairingCode(config.NUMBER);
    const formatted = code.length === 8 ? `${code.slice(0, 4)}-${code.slice(4)}` : code;
    console.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`🔑  CODE DE COUPLAGE WHATSAPP : ${formatted}`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`📱 WhatsApp → Appareils connectés → Lier avec numéro → Entrez: ${formatted}`);
    console.log(`⏱  Valable 60 secondes.\n`);
    let countdown = 60;
    intervalId = setInterval(() => { countdown -= 10; if (countdown > 0) logger.info(`🔑 Code: ${formatted} (expire dans ${countdown}s)`); }, 10000);
    setTimeout(() => { clearInterval(intervalId); logger.warn("⏰ Code expiré. Redémarrez le bot."); }, 60000);
  } catch (err) {
    logger.error({ error: err }, "Échec du code de pairing");
    throw err;
  }
}

// ━━━━━━━━━━━━━━━ MODULES STATE ━━━━━━━━━━━━━━━
const modules = {
  antilink: { enabled: false, groups: new Map() },
  antiinsulte: { enabled: false, words: ["insulte1", "insulte2"] },
  antiflood: { enabled: false, maxMessages: 5, timeWindow: 10000 },
  antibot: { enabled: false },
  antispam: { enabled: false },
  welcome: { enabled: true, messages: new Map() },
  goodbye: { enabled: true, messages: new Map() },
  autoreply: { enabled: true, keywords: new Map() },
  broadcast: { enabled: false },
  levels: { enabled: true, data: new Map() },
  logs: { enabled: true, file: "logs/bot.log" },
};

// Spam tracking
const floodTracker = new Map();
const bannedUsers = new Set();
const blacklist = new Set();
const commandLogs = [];
const scheduledMessages = [];
const activeQuizzes = new Map(); // track quiz answers per chat

// ━━━━━━━━━━━━━━━ UTILS ━━━━━━━━━━━━━━━
function logCommand(from, command) {
  const entry = { from, command, timestamp: new Date().toISOString() };
  commandLogs.push(entry);
  if (modules.logs.enabled) {
    try {
      if (!fs.existsSync("logs")) fs.mkdirSync("logs", { recursive: true });
      fs.appendFileSync(modules.logs.file, JSON.stringify(entry) + "\n");
    } catch {}
  }
}

function checkFlood(from) {
  const now = Date.now();
  const history = floodTracker.get(from) || [];
  const recent = history.filter(t => now - t < modules.antiflood.timeWindow);
  recent.push(now);
  floodTracker.set(from, recent);
  return recent.length > modules.antiflood.maxMessages;
}

function containsInsulte(text) {
  return modules.antiinsulte.words.some(w => text.toLowerCase().includes(w.toLowerCase()));
}

function generateLicenseInfo() {
  return config.LICENSE_KEY
    ? `🔑 Licence: ${config.LICENSE_KEY.substring(0, 8)}...\n✅ Statut: Active`
    : "⚠️ Aucune licence configurée";
}

// ━━━━━━━━━━━━━━━ MAIN ━━━━━━━━━━━━━━━
async function startBot() {
  try {
    logger.info(`🚀 Démarrage de ${config.BOT_NAME} Bot [PREMIUM] by ${config.COMPANY_NAME}...`);
    const { version } = await fetchLatestBaileysVersion();
    const { state, saveCreds } = await useMultiFileAuthState(config.AUTH_DIR);

    socket = makeWASocket({
      version,
      logger: pino({ level: "silent" }),
      printQRInTerminal: false,
      auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, logger) },
      syncFullHistory: false,
      msgRetryCounterCache,
      generateHighQualityLinkPreview: true,
    });

    socket.ev.on("creds.update", saveCreds);

    socket.ev.on("connection.update", ({ connection, lastDisconnect, qr }) => {
      if (qr && config.USE_QR) qrcodeTerminal.generate(qr, { small: true });
      if (!config.USE_QR && qr && config.NUMBER && !state.creds.registered) {
        requestPairingCode(socket).catch(err => logger.error({ err }, "Erreur pairing"));
      }
      if (connection === "open") {
        logger.info(`✅ ${config.BOT_NAME} [PREMIUM] connecté à WhatsApp !`);
        startHeartbeat(socket);
        startScheduledTasks();
      }
      if (connection === "close") {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        if (statusCode !== DisconnectReason.loggedOut) {
          clearInterval(intervalId);
          if (heartbeatInterval) clearInterval(heartbeatInterval);
          logger.info("🔄 Reconnexion...");
          setTimeout(startBot, config.RECONNECT_DELAY);
        } else {
          logger.error("Session invalidée.");
          cleanAuthFolder();
        }
      }
    });

  // ━━━━━━━━━━━━━━━ GROUP EVENTS ━━━━━━━━━━━━━━━
  socket.ev.on("group-participants.update", async (update) => {
    const { id, participants, action } = update;
    for (const participant of participants) {
      if (action === "add" && modules.welcome.enabled) {
        const customMsg = modules.welcome.messages.get(id) || "Bienvenue ! Je suis votre assistant WhatsApp. Tapez !menu pour voir les commandes.";
        const name = participant.split("@")[0];
        await socket.sendMessage(id, { text: customMsg.replace("{user}", `@${name}`).replace("{group}", id), mentions: [participant] });
      }
      if (action === "remove" && modules.goodbye.enabled) {
        const goodbyeMsg = modules.goodbye.messages.get(id) || "👋 Au revoir @{user} !";
        const name = participant.split("@")[0];
        await socket.sendMessage(id, { text: goodbyeMsg.replace("{user}", `@${name}`), mentions: [participant] });
      }
    }
  });

  // ━━━━━━━━━━━━━━━ MESSAGES ━━━━━━━━━━━━━━━
  socket.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      try {
        if (!msg.message) continue;
        if (msg.key.fromMe) continue;
        // Deduplicate
        if (processedMessages.has(msg.key.id)) continue;
        processedMessages.add(msg.key.id);
        if (processedMessages.size > 1000) {
          const arr = [...processedMessages];
          arr.splice(0, 500).forEach(id => processedMessages.delete(id));
        }

        const text = msg.message?.conversation
          || msg.message?.extendedTextMessage?.text
          || msg.message?.ephemeralMessage?.message?.conversation
          || msg.message?.ephemeralMessage?.message?.extendedTextMessage?.text
          || msg.message?.imageMessage?.caption
          || msg.message?.videoMessage?.caption
          || "";
        if (!text) continue;
        const from = msg.key.remoteJid;
        const sender = msg.key.participant || from;
        const isGroup = from?.endsWith("@g.us");
        const p = config.PREFIXE;

        console.log(`[MSG] De: ${from} | Texte: ${text.slice(0, 60)}`);

        // Banned check
        if (bannedUsers.has(sender) || blacklist.has(sender)) {
          continue;
        }

        // Anti-flood
        if (modules.antiflood.enabled && checkFlood(sender)) {
          await socket.sendMessage(from, { text: "⚠️ Anti-flood: vous envoyez trop de messages." });
          continue;
        }

        // Anti-insulte
        if (modules.antiinsulte.enabled && isGroup && containsInsulte(text)) {
          await socket.sendMessage(from, { text: "🚫 Message inapproprié détecté." });
          const isAdmin = await checkIfAdmin(from, sender);
          if (!isAdmin) {
            try { await socket.groupParticipantsUpdate(from, [sender], "remove"); } catch {}
          }
          continue;
        }

        // Anti-link in groups
        if (modules.antilink.enabled && isGroup && text.match(/https?:\/\//i)) {
          const isAdmin = await checkIfAdmin(from, sender);
          if (!isAdmin) {
            await socket.sendMessage(from, { text: "🔗 Les liens ne sont pas autorisés." });
            continue;
          }
        }

        // Anti-bot
        if (modules.antibot.enabled && isGroup && msg.key.fromMe === false && msg.message?.protocolMessage) {
          continue;
        }

        // Auto-reply keywords
        if (modules.autoreply.enabled && !text.startsWith(p)) {
          for (const [keyword, response] of modules.autoreply.keywords) {
            if (text.toLowerCase().includes(keyword.toLowerCase())) {
              await socket.sendMessage(from, { text: response });
              break;
            }
          }
        }

        // Level system
        if (modules.levels.enabled && isGroup) {
          const key = `${from}_${sender}`;
          const current = modules.levels.data.get(key) || { xp: 0, level: 1 };
          current.xp += Math.floor(Math.random() * 10) + 5;
          const newLevel = Math.floor(current.xp / 100) + 1;
          if (newLevel > current.level) {
            current.level = newLevel;
            await socket.sendMessage(from, {
              text: `🎉 @${sender.split("@")[0]} est passé au niveau ${newLevel} !`,
              mentions: [sender],
            });
          }
          modules.levels.data.set(key, current);
        }

        // Check quiz answers before command parsing
        if (activeQuizzes.has(from)) {
          const quiz = activeQuizzes.get(from);
          if (text.toLowerCase().trim() === quiz.answer.toLowerCase()) {
            await socket.sendMessage(from, { text: `✅ Bonne réponse @${sender.split("@")[0]} ! C'était bien *${quiz.answer}* 🎉`, mentions: [sender] });
            activeQuizzes.delete(from);
            continue;
          } else if (!text.startsWith(p)) {
            await socket.sendMessage(from, { text: `❌ Mauvaise réponse ! Essayez encore ou tapez ${p}quiz pour un nouveau quiz.` });
            continue;
          }
        }

        // ━━━━━━━━━━━━━━━ COMMANDS ━━━━━━━━━━━━━━━
        if (!text.startsWith(p)) {
          // AI auto-reply for non-command messages
          await handleAIReply(socket, msg, from, text);
          continue;
        }

        const args = text.slice(p.length).trim().split(/\s+/);
        const cmd = args.shift()?.toLowerCase() || "";
        const argsText = args.join(" ");

        logCommand(sender, cmd);
        console.log(`[CMD] ${cmd} de ${sender}`);

        switch (cmd) {
          // ━━━ GENERAL ━━━
          case "menu": case "help":
            try { await socket.sendMessage(from, { text: generatePremiumMenu(p) }); }
            catch (e) { console.error("[MENU ERROR]", e); await socket.sendMessage(from, { text: "📋 Menu disponible. Tapez " + p + "info pour les infos." }); }
            break;
          case "ping": {
            const start = Date.now();
            await socket.sendMessage(from, { text: `🏓 Pong ! Latence: ${Date.now() - start}ms` });
            break;
          }
          case "info":
            await socket.sendMessage(from, { text: `🤖 *${config.BOT_NAME}* ⚡ PREMIUM\n🏢 ${config.COMPANY_NAME}\n📌 Préfixe: ${p}\n${generateLicenseInfo()}\n🛡️ Anti-spam: Actif\n🔗 Anti-link: Actif\n🤬 Anti-insulte: Actif` });
            break;

          // ━━━ GROUP MANAGEMENT ━━━
          case "kick": case "ban":
            if (isGroup) {
              const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
              if (mentioned?.length) {
                for (const target of mentioned) {
                  try {
                    await socket.groupParticipantsUpdate(from, [target], "remove");
                    if (cmd === "ban") bannedUsers.add(target);
                  } catch {}
                }
                await socket.sendMessage(from, { text: `✅ Utilisateur(s) ${cmd === "ban" ? "banni(s)" : "exclu(s)"}.` });
              }
            }
            break;
          case "add":
            if (isGroup && argsText) {
              const number = argsText.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
              try {
                await socket.groupParticipantsUpdate(from, [number], "add");
                await socket.sendMessage(from, { text: "✅ Utilisateur ajouté." });
              } catch { await socket.sendMessage(from, { text: "❌ Impossible d'ajouter." }); }
            }
            break;
          case "promote":
            if (isGroup) {
              const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
              if (mentioned?.length) {
                await socket.groupParticipantsUpdate(from, mentioned, "promote");
                await socket.sendMessage(from, { text: "⬆️ Promu admin." });
              }
            }
            break;
          case "demote":
            if (isGroup) {
              const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
              if (mentioned?.length) {
                await socket.groupParticipantsUpdate(from, mentioned, "demote");
                await socket.sendMessage(from, { text: "⬇️ Rétrogradé." });
              }
            }
            break;
          case "mute":
            if (isGroup) {
              try { await socket.groupSettingUpdate(from, "announcement"); await socket.sendMessage(from, { text: "🔇 Groupe muté." }); }
              catch { await socket.sendMessage(from, { text: "❌ Erreur: le bot doit être admin du groupe." }); }
            } else { await socket.sendMessage(from, { text: "⚠️ Cette commande fonctionne uniquement en groupe." }); }
            break;
          case "unmute":
            if (isGroup) {
              try { await socket.groupSettingUpdate(from, "not_announcement"); await socket.sendMessage(from, { text: "🔈 Groupe démuté." }); }
              catch { await socket.sendMessage(from, { text: "❌ Erreur: le bot doit être admin du groupe." }); }
            } else { await socket.sendMessage(from, { text: "⚠️ Cette commande fonctionne uniquement en groupe." }); }
            break;
          case "lock":
            if (isGroup) {
              try { await socket.groupSettingUpdate(from, "locked"); await socket.sendMessage(from, { text: "🔒 Groupe verrouillé." }); }
              catch { await socket.sendMessage(from, { text: "❌ Erreur: le bot doit être admin du groupe." }); }
            } else { await socket.sendMessage(from, { text: "⚠️ Cette commande fonctionne uniquement en groupe." }); }
            break;
          case "unlock":
            if (isGroup) {
              try { await socket.groupSettingUpdate(from, "unlocked"); await socket.sendMessage(from, { text: "🔓 Groupe déverrouillé." }); }
              catch { await socket.sendMessage(from, { text: "❌ Erreur: le bot doit être admin du groupe." }); }
            } else { await socket.sendMessage(from, { text: "⚠️ Cette commande fonctionne uniquement en groupe." }); }
            break;
          case "tagall": {
            if (isGroup) {
              const groupMeta = await socket.groupMetadata(from);
              const mentions = groupMeta.participants.map(p => p.id);
              const mentionText = mentions.map(id => `@${id.split("@")[0]}`).join(" ");
              await socket.sendMessage(from, { text: `📢 *Mention générale*\n\n${argsText || "Attention !"} \n\n${mentionText}`, mentions });
            }
            break;
          }
          case "groupinfo": {
            if (isGroup) {
              const meta = await socket.groupMetadata(from);
              await socket.sendMessage(from, {
                text: `📋 *Info Groupe*\n\n📛 Nom: ${meta.subject}\n👥 Membres: ${meta.participants.length}\n📝 Description: ${meta.desc || "Aucune"}\n🆔 ID: ${from}`,
              });
            }
            break;
          }

          // ━━━ WELCOME / GOODBYE ━━━
          case "setwelcome":
            if (isGroup && argsText) {
              modules.welcome.messages.set(from, argsText);
              await socket.sendMessage(from, { text: "✅ Message de bienvenue mis à jour." });
            }
            break;
          case "setgoodbye":
            if (isGroup && argsText) {
              modules.goodbye.messages.set(from, argsText);
              await socket.sendMessage(from, { text: "✅ Message de départ mis à jour." });
            }
            break;

          // ━━━ AUTO-REPLY ━━━
          case "addreply":
            if (argsText.includes("|")) {
              const [keyword, ...responseParts] = argsText.split("|");
              modules.autoreply.keywords.set(keyword.trim(), responseParts.join("|").trim());
              await socket.sendMessage(from, { text: `✅ Auto-réponse ajoutée: "${keyword.trim()}"` });
            } else {
              await socket.sendMessage(from, { text: `Usage: ${p}addreply mot-clé | réponse` });
            }
            break;
          case "delreply":
            if (argsText && modules.autoreply.keywords.delete(argsText.trim())) {
              await socket.sendMessage(from, { text: "✅ Auto-réponse supprimée." });
            }
            break;
          case "listreplies":
            if (modules.autoreply.keywords.size === 0) {
              await socket.sendMessage(from, { text: "Aucune auto-réponse configurée." });
            } else {
              let list = "📋 *Auto-réponses:*\n\n";
              for (const [k, v] of modules.autoreply.keywords) list += `▸ "${k}" → "${v}"\n`;
              await socket.sendMessage(from, { text: list });
            }
            break;

          // ━━━ SECURITY ━━━
          case "antilink":
            modules.antilink.enabled = !modules.antilink.enabled;
            await socket.sendMessage(from, { text: `🔗 Anti-link: ${modules.antilink.enabled ? "Activé ✅" : "Désactivé ❌"}` });
            break;
          case "antiinsulte":
            modules.antiinsulte.enabled = !modules.antiinsulte.enabled;
            await socket.sendMessage(from, { text: `🤬 Anti-insulte: ${modules.antiinsulte.enabled ? "Activé ✅" : "Désactivé ❌"}` });
            break;
          case "antiflood":
            modules.antiflood.enabled = !modules.antiflood.enabled;
            await socket.sendMessage(from, { text: `🌊 Anti-flood: ${modules.antiflood.enabled ? "Activé ✅" : "Désactivé ❌"}` });
            break;
          case "antibot":
            modules.antibot.enabled = !modules.antibot.enabled;
            await socket.sendMessage(from, { text: `🤖 Anti-bot: ${modules.antibot.enabled ? "Activé ✅" : "Désactivé ❌"}` });
            break;
          case "blacklist":
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
              const target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
              blacklist.add(target);
              await socket.sendMessage(from, { text: "🚫 Utilisateur ajouté à la liste noire." });
            }
            break;
          case "unblacklist":
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
              const target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
              blacklist.delete(target);
              await socket.sendMessage(from, { text: "✅ Utilisateur retiré de la liste noire." });
            }
            break;

          // ━━━ BROADCAST ━━━
          case "broadcast":
            if (sender === config.NUMBER + "@s.whatsapp.net" && argsText) {
              const groups = await socket.groupFetchAllParticipating();
              let count = 0;
              for (const [jid] of Object.entries(groups)) {
                try { await socket.sendMessage(jid, { text: `📢 *Broadcast*\n\n${argsText}` }); count++; } catch {}
              }
              await socket.sendMessage(from, { text: `✅ Broadcast envoyé à ${count} groupes.` });
            }
            break;
          case "schedule":
            if (argsText.includes("|")) {
              const [time, ...msgParts] = argsText.split("|");
              const message = msgParts.join("|").trim();
              scheduledMessages.push({ cron: time.trim(), message, target: from });
              await socket.sendMessage(from, { text: `⏰ Message programmé: "${message}" à ${time.trim()}` });
            } else {
              await socket.sendMessage(from, { text: `Usage: ${p}schedule HH:MM | message` });
            }
            break;

          // ━━━ MEDIA TOOLS ━━━
          case "sticker": case "stk": case "tostk": {
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quotedMsg?.imageMessage) {
              try {
                const buffer = await socket.downloadMediaMessage(msg.message.extendedTextMessage.contextInfo.quotedMessage);
                await socket.sendMessage(from, { sticker: buffer }, { quoted: msg });
              } catch { await socket.sendMessage(from, { text: "❌ Erreur conversion sticker." }); }
            } else {
              await socket.sendMessage(from, { text: "Répondez à une image avec cette commande." });
            }
            break;
          }

          // ━━━ FUN ━━━
          case "blague": case "joke": {
            const blagues = [
              "Pourquoi les plongeurs plongent toujours en arrière ? Parce que s'ils plongeaient en avant, ils tomberaient dans le bateau. 😂",
              "C'est l'histoire d'un tétard qui croyait qu'il était tôt... mais en fait il était tard. 🐸",
              "Que dit un informaticien quand il a froid ? 'Je vais mettre un pull-over.' 🧥",
              "Comment appelle-t-on un chat tombé dans un pot de peinture le jour de Noël ? Un chat-peint de Noël ! 🎄",
            ];
            await socket.sendMessage(from, { text: blagues[Math.floor(Math.random() * blagues.length)] });
            break;
          }
          case "quiz": {
             const quizzes = [
              { q: "Quelle est la capitale de la France ?", a: "Paris" },
              { q: "Combien de continents y a-t-il ?", a: "7" },
              { q: "Quel est le plus grand océan ?", a: "Pacifique" },
              { q: "Quelle planète est la plus proche du soleil ?", a: "Mercure" },
              { q: "Combien de joueurs dans une équipe de football ?", a: "11" },
            ];
            const quiz = quizzes[Math.floor(Math.random() * quizzes.length)];
            activeQuizzes.set(from, { answer: quiz.a, timestamp: Date.now() });
            await socket.sendMessage(from, { text: `🧩 *Quiz*\n\n${quiz.q}\n\n_Répondez directement dans le chat !_` });
            break;
          }

          // ━━━ MODULES ━━━
          case "modules": {
            let status = "📦 *Modules:*\n\n";
            for (const [name, mod] of Object.entries(modules)) {
              status += `${mod.enabled ? "✅" : "❌"} ${name}\n`;
            }
            await socket.sendMessage(from, { text: status });
            break;
          }
          case "enable":
            if (argsText && modules[argsText]) {
              modules[argsText].enabled = true;
              await socket.sendMessage(from, { text: `✅ Module ${argsText} activé.` });
            }
            break;
          case "disable":
            if (argsText && modules[argsText]) {
              modules[argsText].enabled = false;
              await socket.sendMessage(from, { text: `❌ Module ${argsText} désactivé.` });
            }
            break;

          // ━━━ LOGS ━━━
          case "logs": {
            const recent = commandLogs.slice(-10);
            let logText = "📋 *Dernières commandes:*\n\n";
            for (const log of recent) {
              logText += `▸ ${log.command} par ${log.from.split("@")[0]} à ${log.timestamp}\n`;
            }
            await socket.sendMessage(from, { text: logText });
            break;
          }
          case "stats": {
            const totalCmds = commandLogs.length;
            const uniqueUsers = new Set(commandLogs.map(l => l.from)).size;
            await socket.sendMessage(from, {
              text: `📊 *Statistiques*\n\n📝 Commandes: ${totalCmds}\n👥 Utilisateurs: ${uniqueUsers}\n📦 Modules actifs: ${Object.values(modules).filter(m => m.enabled).length}/${Object.keys(modules).length}\n🚫 Bannis: ${bannedUsers.size}\n⏰ Uptime: ${Math.floor(process.uptime() / 60)} min`,
            });
            break;
          }

          // ━━━ LICENSE ━━━
          case "license":
            await socket.sendMessage(from, { text: generateLicenseInfo() });
            break;

          // ━━━ LEVEL ━━━
          case "rank": case "level": {
            const key = `${from}_${sender}`;
            const data = modules.levels.data.get(key) || { xp: 0, level: 1 };
            await socket.sendMessage(from, {
              text: `📊 *Votre rang*\n\n⭐ Niveau: ${data.level}\n✨ XP: ${data.xp}\n📈 Prochain: ${data.level * 100 - data.xp} XP restants`,
            });
            break;
          }

          // ━━━ PERSONALIZATION ━━━
          case "setname":
            if (argsText) {
              config.BOT_NAME = argsText;
              await socket.sendMessage(from, { text: `✅ Nom du bot: ${argsText}` });
            }
            break;
          case "setprefix":
            if (argsText) {
              config.PREFIXE = argsText;
              await socket.sendMessage(from, { text: `✅ Préfixe: ${argsText}` });
            }
            break;

          // ━━━ IA ━━━
          case "ia": {
            const query = argsText.trim();
            if (query) await handleAIReply(socket, msg, from, query);
            else await socket.sendMessage(from, { text: `Usage: ${p}ia [votre question]` });
            break;
          }

          default:
            await socket.sendMessage(from, { text: `❓ Commande inconnue. Tapez ${p}menu` });
        }
      } catch (err) {
        console.error("[ERREUR MESSAGE]", err);
      }
    }
  });
  } catch (err) {
    logger.error({ err }, "Erreur fatale");
    setTimeout(startBot, config.RECONNECT_DELAY);
  }
}

async function checkIfAdmin(groupJid, participantJid) {
  try {
    const groupMeta = await socket.groupMetadata(groupJid);
    return groupMeta.participants.some(p => p.id === participantJid && (p.admin === "admin" || p.admin === "superadmin"));
  } catch { return false; }
}

function startScheduledTasks() {
  // Check scheduled messages every minute
  cron.schedule("* * * * *", () => {
    const now = new Date();
    const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    for (const scheduled of scheduledMessages) {
      if (scheduled.cron === currentTime) {
        socket.sendMessage(scheduled.target, { text: scheduled.message }).catch(() => {});
      }
    }
  });
  logger.info("⏰ Tâches programmées initialisées");
}

function generatePremiumMenu(p) {
  return `
━━━━━━━━━━━━━━━━━━━━━━━━━
  🤖 *${config.BOT_NAME}* ⚡ PREMIUM
  ${config.COMPANY_NAME}
━━━━━━━━━━━━━━━━━━━━━━━━━

📋 *Général*
  ⚡ ${p}ping - Latence
  📋 ${p}menu - Ce menu
  🔍 ${p}info - Infos du bot
  📊 ${p}stats - Statistiques
  🔑 ${p}license - Info licence
  🤖 ${p}ia [question] - Poser une question à l'IA

👥 *Gestion de groupe*
  📢 ${p}tagall [msg] - Mentionner tous
  ➕ ${p}add [numéro] - Ajouter membre
  🚫 ${p}kick @user - Exclure
  ⛔ ${p}ban @user - Bannir
  🔇 ${p}mute - Muter groupe
  🔈 ${p}unmute - Démuter
  ⬆️ ${p}promote @user - Promouvoir
  ⬇️ ${p}demote @user - Rétrograder
  🔒 ${p}lock - Verrouiller
  🔓 ${p}unlock - Déverrouiller
  📋 ${p}groupinfo - Info groupe

🎉 *Welcome / Goodbye*
  👋 ${p}setwelcome [msg]
  👋 ${p}setgoodbye [msg]

🤖 *Auto-réponse*
  ➕ ${p}addreply mot | réponse
  ➖ ${p}delreply mot
  📋 ${p}listreplies

🛡️ *Sécurité*
  🔗 ${p}antilink - Toggle
  🤬 ${p}antiinsulte - Toggle
  🌊 ${p}antiflood - Toggle
  🤖 ${p}antibot - Toggle
  🚫 ${p}blacklist @user
  ✅ ${p}unblacklist @user

📢 *Broadcast*
  📣 ${p}broadcast [msg]
  ⏰ ${p}schedule HH:MM | msg

🎨 *Média*
  🖼️ ${p}sticker - Image → sticker

🎮 *Fun*
  😂 ${p}blague
  🧩 ${p}quiz

📊 *Niveaux*
  ⭐ ${p}rank - Votre niveau

📦 *Modules*
  📋 ${p}modules - Liste
  ✅ ${p}enable [module]
  ❌ ${p}disable [module]

📝 *Logs*
  📋 ${p}logs - Historique

⚙️ *Personnalisation*
  📝 ${p}setname [nom]
  📌 ${p}setprefix [préfixe]

💡 Envoyez n'importe quel message pour parler à l'IA !

━━━━━━━━━━━━━━━━━━━━━━━━━
  Généré par BotForge ⚡
━━━━━━━━━━━━━━━━━━━━━━━━━`;
}

startBot().catch(console.error);
